// Relatório de aprendizado: o que ainda está indo para o LLM (custa) e deveria virar resposta pronta.
// Uso: node src/tools/relatorio.js [dias=7]
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const DATA = process.env.DATA_DIR || path.join(ROOT, 'data');
const dias = +(process.argv[2] || 7);
const desde = Date.now() - dias * 864e5;
const linhas = fs.existsSync(path.join(DATA, 'aprender.jsonl')) ? fs.readFileSync(path.join(DATA, 'aprender.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map((l) => JSON.parse(l)) : [];
const rec = linhas.filter((r) => Date.parse(r.ts) >= desde);
const tiers = {};
const llm = new Map();
for (const r of rec) {
  const t = r.tier || (r.resposta ? 'llm' : 'outro');
  tiers[t] = (tiers[t] || 0) + 1;
  if (t === 'llm') {
    const k = `${r.brand}|${r.intent || r.pista || '?'}`;
    const e = llm.get(k) || { brand: r.brand, intent: r.intent || r.pista || '?', n: 0, custo: 0, exemplos: [] };
    e.n++; e.custo += r.custo || 0;
    if (e.exemplos.length < 6) e.exemplos.push(r.raw || r.norm);
    llm.set(k, e);
  }
}
const total = rec.length || 1;
console.log(`Últimos ${dias} dias: ${rec.length} mensagens`);
for (const [t, n] of Object.entries(tiers).sort((a, b) => b[1] - a[1])) console.log(`  ${t.padEnd(10)} ${String(n).padStart(5)}  ${((100 * n) / total).toFixed(1)}%`);
const met = JSON.parse(fs.existsSync(path.join(DATA, 'metricas.json')) ? fs.readFileSync(path.join(DATA, 'metricas.json'), 'utf8') : '{"dias":{}}');
let custo = 0, conv = 0;
for (const [d, marcas] of Object.entries(met.dias)) if (Date.parse(d) >= desde - 864e5) for (const m of Object.values(marcas)) { custo += m.custo_usd || 0; conv += m.conversas || 0; }
console.log(`\nCusto de IA: US$ ${custo.toFixed(4)} · conversas: ${conv} · por conversa: US$ ${(custo / (conv || 1)).toFixed(5)}`);
console.log('\nO que mais foi para o LLM (candidatos a resposta pronta):');
for (const e of [...llm.values()].sort((a, b) => b.n - a.n).slice(0, 25)) {
  console.log(`\n[${e.brand}] ${e.intent} · ${e.n}x · US$ ${e.custo.toFixed(4)}`);
  for (const x of e.exemplos) console.log('   - ' + String(x).slice(0, 120));
}
