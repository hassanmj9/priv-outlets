// Gera as "Respostas prontas" do Chatwoot a partir das intenções da marca: a equipe digita /atalho
// e responde com o mesmo texto do bot (mesma voz, zero custo).
// Uso: node src/tools/respostas_prontas.js packs/priv            -> imprime JSON [{short_code, content}]
//      CHATWOOT_URL=... CHATWOOT_USER_TOKEN=... node src/tools/respostas_prontas.js packs/priv --enviar
//      (o token é o "Token de acesso" do seu perfil no Chatwoot; o token do robô não tem essa permissão)
import fs from 'node:fs';
import path from 'node:path';

const dir = path.resolve(process.argv[2] || 'packs/priv');
const read = (f, d) => { try { return JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')); } catch { return d; } };
const brand = read('brand.json', {});
const { intents = [] } = read('intents.json', {});
const facts = { ...(brand.fatos || {}), ...(brand.links || {}) };
const fill = (t) => String(t).replace(/\{\{\s*([\w.]+)\s*\}\}/g, (_, k) => (k === 'nome' ? '{{contact.name}}' : facts[k] ?? '')).replace(/ {2,}/g, ' ').trim();
const SKIP = /^(saudacao|despedida|agradecimento|fora_escopo|audio_recebido|imagem_recebida|ofensa|spam|teste)/;

const out = intents
  .filter((i) => !SKIP.test(i.id) && (i.answer || []).length && !/\{\{\s*(produto|preco|link)\s*\}\}/.test(i.answer[0]))
  .map((i) => ({ short_code: `${brand.id || path.basename(dir)}-${i.id}`.replace(/_/g, '-').slice(0, 40), content: fill(i.answer[0]) }));

if (!process.argv.includes('--enviar')) { console.log(JSON.stringify(out, null, 2)); process.exit(0); }
const url = (process.env.CHATWOOT_URL || '').replace(/\/$/, ''), tok = process.env.CHATWOOT_USER_TOKEN, acc = process.env.CHATWOOT_ACCOUNT_ID || 1;
if (!url || !tok) { console.error('defina CHATWOOT_URL e CHATWOOT_USER_TOKEN'); process.exit(1); }
const h = { api_access_token: tok, 'content-type': 'application/json' };
const cur = await fetch(`${url}/api/v1/accounts/${acc}/canned_responses`, { headers: h }).then((r) => r.json());
const have = new Map((Array.isArray(cur) ? cur : cur.payload || []).map((c) => [c.short_code, c]));
let n = 0;
for (const c of out) {
  const old = have.get(c.short_code);
  if (old && old.content === c.content) continue;
  const r = await fetch(`${url}/api/v1/accounts/${acc}/canned_responses${old ? '/' + old.id : ''}`, { method: old ? 'PATCH' : 'POST', headers: h, body: JSON.stringify({ canned_response: c }) });
  if (r.ok) n++; else console.error(c.short_code, r.status);
}
console.log(`${n} respostas prontas criadas/atualizadas de ${out.length}`);
