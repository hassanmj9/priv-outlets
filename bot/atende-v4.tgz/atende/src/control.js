// Quem está no controle da conversa: o bot (status "pending" no Chatwoot) ou a equipe ("open").
// O bot volta a atender uma conversa da equipe quando:
//  - equipe_2h: o cliente escreve e ninguém da equipe respondeu em 2 h desde o transbordo;
//  - cliente_24h: o cliente escreve de novo depois de 24 h sem conversa e sem resposta da equipe nesse período.
// Funções puras sobre o estado da conversa (store.conv[key]); o servidor faz as chamadas ao Chatwoot.
export const H = 36e5;
export const RESUME_AFTER = { equipe: 2 * H, cliente: 24 * H };
const BURST = 10 * 60e3; // mensagens picadas logo depois da retomada seguem com o bot

// resposta de alguém da equipe ao cliente (não vale nota interna nem mensagem do próprio bot)
export function isHumanReply(ev) {
  if (ev.message_type !== 'outgoing' || ev.private) return false;
  return ev.sender?.type === 'user' || !!ev.content_attributes?.external_echo;
}

export function onHuman(st, now) {
  st.humanTs = now;
  st.waitTs = null; // cliente deixou de esperar
  st.handoff = true; // equipe no controle
  st.handoffTs = now;
}

// chamada para TODA mensagem do cliente, depois de decidir (usa os valores anteriores)
export function onIncoming(st, now, conv) {
  const cwWait = (+conv?.waiting_since || 0) * 1000;
  if (st.waitTs === undefined && cwWait && cwWait < now) st.waitTs = cwWait; // conversa de antes deste controle
  if (!st.waitTs) st.waitTs = now; // início da espera por resposta da equipe
  st.lastIn = now;
}

// conversa fora do bot: devolve o motivo para retomar, ou null para ficar quieto
// conv: dados da conversa que vêm no webhook (waiting_since, se o Chatwoot informar, confirma a espera)
export function resumeReason(st, conv, now) {
  if (!st) return null;
  if (st.resumeTs && now - st.resumeTs < BURST && !st.handoff) return 'retomada';
  const human = st.humanTs || 0;
  const prevIn = st.lastIn ?? st.ts ?? 0;
  if (prevIn && now - prevIn > RESUME_AFTER.cliente && now - human > RESUME_AFTER.cliente) return 'cliente_24h';
  const since = st.handoffTs ?? (st.handoff ? st.ts : null);
  if (since == null || now - since < RESUME_AFTER.equipe) return null;
  const cwWait = conv && 'waiting_since' in conv ? (+conv.waiting_since || 0) * 1000 : undefined;
  const wait = st.waitTs !== undefined ? st.waitTs : cwWait; // conversas de antes deste controle: usa o Chatwoot
  if (!wait || now - wait < RESUME_AFTER.equipe || human > wait) return null;
  // o Chatwoot zera waiting_since quando alguém da equipe responde: se ele diz que não há espera longa, fica quieto
  if (cwWait !== undefined && (!cwWait || now - cwWait < RESUME_AFTER.equipe)) return null;
  return 'equipe_2h';
}

export function onResume(st, why, now) {
  st.handoff = false;
  st.resumeTs = now;
  st.resumes = (st.resumes || 0) + 1;
  if (why === 'equipe_2h') st.pendingApology = true;
}

export const RESUME_NOTE = {
  equipe_2h: 'Bot voltou a atender: o cliente escreveu de novo e ninguém da equipe respondeu em 2 h. Para assumir, é só responder o cliente: o bot para.',
  cliente_24h: 'Bot voltou a atender: o cliente escreveu depois de 24 h sem conversa. Para assumir, é só responder o cliente: o bot para.',
};
