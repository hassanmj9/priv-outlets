// Cliente da API do Chatwoot usado pelo bot (token de Agent Bot).
export const btnTitle = (b) => { const t = String(b).trim(); return t.length <= 20 ? t : t.slice(0, 19).replace(/\s+\S*$/, '') + '…'; };
export class Chatwoot {
  constructor({ url, accountId, token }) {
    this.url = (url || '').replace(/\/$/, '');
    this.acc = accountId || 1;
    this.token = token;
  }

  async req(method, p, body, isForm = false) {
    const r = await fetch(`${this.url}/api/v1/accounts/${this.acc}${p}`, {
      method,
      headers: { api_access_token: this.token, ...(isForm ? {} : { 'content-type': 'application/json' }) },
      body: body ? (isForm ? body : JSON.stringify(body)) : undefined,
      signal: AbortSignal.timeout(15000),
    });
    if (!r.ok) throw new Error(`chatwoot ${method} ${p} ${r.status} ${(await r.text()).slice(0, 200)}`);
    return r.json().catch(() => ({}));
  }

  send(conv, content, opts = {}) {
    const body = { content, message_type: 'outgoing', private: !!opts.private };
    if (opts.buttons?.length && opts.interactive !== false) {
      body.content_type = 'input_select';
      // WhatsApp: até 3 botões de até 20 caracteres (o Chatwoot não corta; a Meta recusa se passar)
      const items = [...new Set(opts.buttons.map(btnTitle))].slice(0, 3).map((t) => ({ title: t, value: t }));
      body.content_attributes = { items };
    }
    return this.req('POST', `/conversations/${conv}/messages`, body);
  }

  note(conv, content) { return this.send(conv, content, { private: true }); }

  // envia uma imagem a partir de uma URL (baixa e reenvia como anexo)
  async sendImage(conv, imageUrl, caption = '') {
    const img = await fetch(imageUrl, { signal: AbortSignal.timeout(15000) });
    if (!img.ok) throw new Error('imagem ' + img.status);
    const buf = Buffer.from(await img.arrayBuffer());
    const fd = new FormData();
    fd.append('content', caption);
    fd.append('message_type', 'outgoing');
    fd.append('attachments[]', new Blob([buf], { type: img.headers.get('content-type') || 'image/jpeg' }), imageUrl.split('/').pop() || 'foto.jpg');
    return this.req('POST', `/conversations/${conv}/messages`, fd, true);
  }

  async labels(conv) { const j = await this.req('GET', `/conversations/${conv}/labels`); return j.payload || []; }

  // troca a etiqueta de etapa do funil mantendo as demais
  async setStage(conv, stage, stageLabels, extra = []) {
    const cur = await this.labels(conv);
    const keep = cur.filter((l) => !stageLabels.includes(l));
    const next = Array.from(new Set([...keep, ...(stage ? [stage] : []), ...extra]));
    if (next.sort().join() === [...cur].sort().join()) return cur;
    await this.req('POST', `/conversations/${conv}/labels`, { labels: next });
    return next;
  }

  status(conv, status) { return this.req('POST', `/conversations/${conv}/toggle_status`, { status }); }

  conversation(conv) { return this.req('GET', `/conversations/${conv}`); }
}

// Chatwoot falso para simulação e testes: guarda tudo o que seria enviado
export class FakeChatwoot {
  constructor() { this.out = []; this.lab = {}; this.st = {}; }
  async send(conv, content, opts = {}) { this.out.push({ conv, type: opts.private ? 'nota' : 'texto', content, buttons: opts.buttons || [] }); return {}; }
  async note(conv, content) { return this.send(conv, content, { private: true }); }
  async sendImage(conv, url, caption) { this.out.push({ conv, type: 'imagem', content: caption, url }); return {}; }
  async labels(conv) { return this.lab[conv] || []; }
  async setStage(conv, stage, stageLabels, extra = []) { const cur = this.lab[conv] || []; this.lab[conv] = Array.from(new Set([...cur.filter((l) => !stageLabels.includes(l)), ...(stage ? [stage] : []), ...extra])); return this.lab[conv]; }
  async status(conv, s) { this.st[conv] = s; return {}; }
  async conversation(conv) { return { id: conv, status: this.st[conv] || 'pending' }; }
}
