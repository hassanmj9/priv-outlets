// Fluxos guiados (flows.json do pacote): perguntas em passos, com botões, slots e pontuação de lead.
// Custo zero: nada aqui chama LLM. Convenções (iguais para todas as marcas):
//   flow: { id, trigger: [intenções], audience?, set?{}, labels?[], route?[...], steps: [...] }
//   step: { id, say, say_<idioma|submarca>, buttons, buttons_<idioma|submarca>, save,
//           expect: text|zip|cep|choice|number|money|date|media,
//           on: { "<botão em qualquer idioma>" | "*": "next" | "step:<id>" | "<fluxo>" | "<intenção>" | "router" | "llm" | "handoff" | "end" },
//           only_if / skip_if (expressão: slot, ==, !=, >=, <=, and, or, not, parênteses),
//           labels[], score, score_by_button{}, score_media, notify, set{}, handoff, route[] }
//   route: [{ if | else, append?, say?, buttons?, labels?, go?, notify?|nota? }]  (avaliado ao entrar no passo/fluxo)
//   doc.consent: { slot, flow }  -> passo com "save" só roda com consentimento; senão abre o fluxo de consentimento

const EXPECT = {
  zip: /\b\d{5}(?:-?\d{3,4})?\b|[a-z]{3,}/i,
  cep: /\b\d{5}-?\d{3}\b/,
  number: /\d/,
  money: /\d|\b(mil|cem|duzentos|trezentos|quinhentos|reais|real|dolares|euros)\b/i,
};
const RESERVED = ['router', 'llm', 'handoff', 'end'];

// "sim"/"não" digitado no lugar do botão: escolhe o único botão de sim/não mostrado
const YES = /^(sim|s|ss|sim sim|claro|aceito|concordo|pode|pode sim|pode seguir|ok|okay|beleza|bora|isso|com certeza|quero sim|sim pode|sim quero|sim aceito|sim claro|yes|yep|yeah|sure|si|dale|por favor)\b/;
const NO = /^(nao|n|nn|agora nao|nao precisa|nao obrigad[oa]|nao quero|nao concordo|depois|no|nope|no thanks|no gracias)\b/;
const YES_BTN = /^(sim|yes|si|pode me|pode seguir|aceito|concordo|claro|quero sim)/;
const NO_BTN = /^(nao|no|agora nao|depois)/;
export function yesNoButton(norm, buttons, normalize) {
  if (!norm || !buttons?.length) return null;
  const nb = buttons.map((b) => normalize(b));
  const pickBy = (rx) => { const idx = nb.map((b, i) => (rx.test(b) ? i : -1)).filter((i) => i >= 0); return idx.length === 1 ? idx[0] : -1; };
  let i = -1;
  if (NO.test(norm)) i = pickBy(NO_BTN);
  else if (YES.test(norm)) i = pickBy(YES_BTN);
  return i >= 0 ? buttons[i] : null;
}

// texto com variante: sub-marca primeiro, depois idioma, depois padrão
export function V(obj, key, st = {}) {
  for (const v of [st.sub, st.lang]) if (v && obj?.[`${key}_${v}`] != null) return obj[`${key}_${v}`];
  return obj?.[key];
}
export const L = (obj, key, lang) => V(obj, key, { lang });

export class Flows {
  constructor(doc = {}, { normalize, matcher, langs = [] }) {
    this.doc = doc;
    this.list = Array.isArray(doc.flows) ? doc.flows : [];
    this.byId = new Map(this.list.map((f) => [f.id, f]));
    this.byTrigger = new Map();
    for (const f of this.list) for (const t of [].concat(f.trigger || [])) if (!this.byTrigger.has(t)) this.byTrigger.set(t, f);
    this.normalize = normalize;
    this.matcher = matcher;
    this.langs = langs;
    this.maxIdle = doc.conventions?.max_turnos_sem_avanco || 6;
    this.events = doc.events || {};
    this.followups = Array.isArray(doc.followups) ? doc.followups : [];
    this.consent = doc.consent?.slot && doc.consent?.flow ? doc.consent : null;
    // não perguntar de novo CEP/ZIP que o cliente já deu
    for (const f of this.list) for (const st of f.steps || []) if (st.save && /^(cep|zip)$/.test(st.expect || '') && !st.skip_if) st.skip_if = st.save;
  }

  get size() { return this.list.length; }
  forIntent(id) { return id ? this.byTrigger.get(id) : null; }

  // ---------- expressões sobre slots (sem eval) ----------
  ctx(st) { return { ...(st.flags || {}), ...(st.slots || {}), score: st.score || 0, brand: st.sub || '', lang: st.lang || '' }; }

  test(expr, st) {
    if (expr == null || expr === '') return true;
    const toks = String(expr).match(/'[^']*'|"[^"]*"|>=|<=|==|!=|[()<>!]|[\w.-]+/g) || [];
    let i = 0;
    const c = this.ctx(st);
    const val = (t) => (/^['"]/.test(t) ? t.slice(1, -1) : /^-?\d+(\.\d+)?$/.test(t) ? +t : t === 'true' ? true : t === 'false' ? false : c[t] ?? '');
    const truthy = (v) => v !== '' && v !== false && v != null && v !== 0;
    const eq = (a, b) => (typeof a === 'number' || typeof b === 'number' ? +a === +b : this.normalize(String(a)) === this.normalize(String(b)));
    const atom = () => {
      const t = toks[i++];
      if (t === '(') { const v = or(); i++; return v; }
      if (t === 'not' || t === '!') return { v: !truthy(atom().v) };
      return { v: val(t) };
    };
    const cmp = () => {
      const a = atom(); const op = toks[i];
      if (['==', '!=', '>=', '<=', '>', '<'].includes(op)) {
        i++; const b = atom().v;
        const r = op === '==' ? eq(a.v, b) : op === '!=' ? !eq(a.v, b) : op === '>=' ? +a.v >= +b : op === '<=' ? +a.v <= +b : op === '>' ? +a.v > +b : +a.v < +b;
        return { v: r };
      }
      return { v: truthy(a.v) };
    };
    const and = () => { let v = cmp().v; while (toks[i] === 'and') { i++; const w = cmp().v; v = v && w; } return { v }; };
    const or = () => { let v = and().v; while (toks[i] === 'or') { i++; const w = and().v; v = v || w; } return { v }; };
    try { return !!or().v; } catch { return false; }
  }

  applicable(step, st) {
    if (step.only_if && !this.test(step.only_if, st)) return false;
    if (step.skip_if && this.test(step.skip_if, st)) return false;
    return true;
  }

  nextFrom(flow, i, st) {
    for (let k = i; k < (flow.steps || []).length; k++) if (this.applicable(flow.steps[k], st)) return k;
    return -1;
  }

  setVars(st, obj, fill) {
    if (!obj) return;
    for (const [k, v] of Object.entries(obj)) { const x = typeof v === 'string' ? fill(v, st, {}) : v; (st.slots ||= {})[k] = x; (st.flags ||= {})[k] = x; }
  }

  // ---------- rotas condicionais ----------
  route(rules, st, fill) {
    const out = { appends: [], buttons: null, labels: [], say: null, go: null, notify: null };
    for (const r of rules || []) {
      if (!(r.else || this.test(r.if, st))) continue;
      out.labels.push(...(r.labels || []));
      if (r.append) { out.appends.push(fill(r.append, st, st.slots)); if (r.buttons) out.buttons = r.buttons; continue; }
      if (r.say) out.say = fill(V(r, 'say', st), st, st.slots);
      if (r.buttons) out.buttons = r.buttons;
      const n = r.notify || r.nota; if (n) out.notify = fill(n, st, st.slots);
      out.go = r.go || null;
      if (r.go || r.say) break;
    }
    return out;
  }

  // ---------- entrada ----------
  start(flow, st, lang, fill) {
    st.slots ||= {};
    if (lang) st.lang ||= lang;
    if (flow.audience && flow.audience !== 'both') st.audience = flow.audience;
    // consentimento antes de coletar dados
    if (this.consent && flow.id !== this.consent.flow && !this.test(this.consent.slot, st) && (flow.steps || []).some((s) => s.save) && this.byId.has(this.consent.flow)) {
      st.afterConsent = flow.id;
      return this.start(this.byId.get(this.consent.flow), st, lang, fill);
    }
    this.setVars(st, flow.set, fill);
    const labels = flow.labels || [];
    if (flow.route) {
      const r = this.route(flow.route, st, fill);
      const target = r.go && this.byId.get(r.go);
      if (target && target !== flow) { const p = this.start(target, st, lang, fill); if (p) return { ...p, labels: [...labels, ...r.labels, ...(p.labels || [])] }; }
      if (r.say || r.go) { st.flow = null; return { text: [r.say, ...r.appends].filter(Boolean).join('\n\n'), buttons: r.buttons || [], tier: 'fluxo', intent: flow.id, labels: [...labels, ...r.labels], handoff: r.go === 'handoff' ? flow.id : false, notify: r.notify }; }
    }
    const i = this.nextFrom(flow, 0, st);
    if (i < 0) return null;
    st.flow = { id: flow.id, i, idle: 0, retry: 0 };
    const p = this.enter(flow, i, st, lang, fill);
    return { ...p, labels: [...labels, ...(p.labels || [])] };
  }

  enter(flow, i, st, lang, fill) {
    const step = flow.steps[i];
    st.flow = { ...(st.flow || { idle: 0, retry: 0 }), id: flow.id, i };
    let text = fill(V(step, 'say', st) || '', st, st.slots);
    let buttons = V(step, 'buttons', st) || [];
    let labels = [...(step.labels || [])];
    let handoff = step.handoff ? `${flow.id}.${step.id}` : false;
    let notify = null;
    if (step.route) {
      const r = this.route(step.route, st, fill);
      text = [r.say || text, ...r.appends].filter(Boolean).join('\n\n');
      if (r.buttons) buttons = r.buttons;
      labels.push(...r.labels);
      notify = r.notify;
      if (r.go === 'handoff') { handoff = `${flow.id}.${step.id}`; st.flow = null; }
      else if (r.go === 'end') st.flow = null;
      else if (r.go && this.byId.has(r.go)) { const p = this.start(this.byId.get(r.go), st, lang, fill); if (p) return { ...p, text: [text, p.text].filter(Boolean).join('\n\n'), labels: [...labels, ...(p.labels || [])] }; }
    }
    const terminal = !step.on && !step.save && !step.expect && !buttons.length;
    if (st.flow && (terminal || (step.on && Object.keys(step.on).length === 1 && step.on['*'] === 'end'))) st.flow = null;
    return { text, buttons, tier: 'fluxo', intent: `${flow.id}.${step.id}`, labels, stage: labels.find((l) => /^\d-/.test(l)) || null, handoff, notify, localized: !!(st.lang && step[`say_${st.lang}`]) };
  }

  // botão clicado em qualquer idioma/sub-marca -> título canônico (padrão)
  matchButton(step, norm, st = {}) {
    const extra = [st.sub, ...this.langs].filter(Boolean);
    const sets = [step.buttons || [], ...extra.map((l) => step[`buttons_${l}`] || [])];
    for (const set of sets) {
      const idx = set.findIndex((b) => this.normalize(b) === norm);
      if (idx >= 0) return { idx, clicked: set[idx], canon: (step.buttons || set)[idx] ?? set[idx] };
    }
    const shown = V(step, 'buttons', st) || [];
    if (/^[1-9]$/.test(norm) && shown.length >= +norm) { const idx = +norm - 1; return { idx, clicked: shown[idx], canon: (step.buttons || shown)[idx] ?? shown[idx] }; }
    for (const k of Object.keys(step.on || {})) if (k !== '*' && this.normalize(k) === norm) return { idx: -1, clicked: k, canon: k };
    const yn = yesNoButton(norm, shown, this.normalize);
    if (yn) { const idx = shown.indexOf(yn); return { idx, clicked: yn, canon: (step.buttons || shown)[idx] ?? yn }; }
    return null;
  }

  // resposta do cliente com um fluxo ativo -> { plan } | { action, target } | null (sair e seguir o roteador)
  handle(st, { norm, raw, attachments, lang, fill }) {
    const flow = this.byId.get(st.flow?.id);
    if (!flow) { st.flow = null; return null; }
    const step = flow.steps?.[st.flow.i];
    if (!step) { st.flow = null; return null; }
    st.flow.idle++;
    if (st.flow.idle > this.maxIdle) { st.flow = null; return null; }

    const btn = norm ? this.matchButton(step, norm, st) : null;
    if (!btn && norm && this.offTopic && this.isQuestion(raw || '', norm) && this.offTopic(norm) && !/produto|peca|item|categoria|procura/.test(step.save || '')) { st.flow = null; return null; }
    const star = step.on?.['*'];
    const freeOk = !!star && !(star === 'next' || star.startsWith('step:'));
    const media = !!attachments?.length;
    let valid = !!btn;
    if (!btn) {
      const exp = step.expect || (step.buttons?.length ? 'choice' : 'text');
      if (exp === 'media') valid = media || (!!star && !this.isInterrupt(norm, flow, 0.7, raw));
      else if (media) valid = false;
      else if (exp === 'choice') valid = !!star && (freeOk || !this.isInterrupt(norm, flow));
      else if (EXPECT[exp]) valid = EXPECT[exp].test(raw) && !this.isInterrupt(norm, flow, 0.7, raw);
      else valid = norm.length > 0 && !this.isInterrupt(norm, flow, 0.7, raw);
    }
    if (!valid) {
      if (st.flow.retry < 1) { st.flow.retry++; return { action: 'interrupt', repeat: this.enter(flow, st.flow.i, st, lang, fill) }; }
      st.flow = null; return null;
    }
    st.flow.retry = 0;
    if (step.save) st.slots[step.save] = btn ? btn.canon : media ? 'recebidas' : raw.slice(0, 200);
    let score = step.score || 0;
    if (btn && step.score_by_button) score += step.score_by_button[btn.canon] || step.score_by_button[btn.clicked] || 0;
    if (media) score += step.score_media ?? 10;
    st.score = (st.score || 0) + score; // já conta para as condições dos próximos passos
    this.setVars(st, step.set, fill);
    const notify = step.notify ? fill(typeof step.notify === 'string' ? step.notify : `Lead em ${flow.id}: {{resumo}}`, st, { ...st.slots, resumo: JSON.stringify(st.slots) }) : null;
    const go = (btn && step.on && (step.on[btn.canon] || step.on[btn.clicked])) || star || 'next';
    const extra = { score: 0, notify, labels: [] };

    if (go === 'next' || go.startsWith('step:')) {
      const i = go === 'next' ? this.nextFrom(flow, st.flow.i + 1, st) : flow.steps.findIndex((s) => s.id === go.slice(5));
      if (i < 0) { st.flow = null; return { action: 'end', ...extra }; }
      const p = this.enter(flow, i, st, lang, fill);
      return { plan: { ...p, notify: p.notify || notify } };
    }
    if (RESERVED.includes(go)) { st.flow = null; return { action: go, ...extra }; }
    if (this.byId.has(go)) { st.flow = null; const p = this.start(this.byId.get(go), st, lang, fill); return p ? { plan: { ...p, notify: p.notify || notify } } : { action: 'end', ...extra }; }
    st.flow = null;
    return { action: 'intent', target: go, ...extra };
  }

  // resposta livre só é tratada como "outra pergunta" se parecer pergunta
  isQuestion(raw, norm) { return /\?/.test(raw) || /^(como|quanto|qual|quais|onde|quando|por que|porque|pode|tem|aceita|faz|what|how|where|when|why|is|are|do|does|can|cuanto|cuando|donde|puedo|tienen|hay)\b/.test(norm); }

  isInterrupt(norm, flow, min = 0.6, raw = null) {
    if (!this.matcher || !norm) return false;
    if (raw != null && !this.isQuestion(raw, norm)) return false;
    const c = this.matcher.classify(norm, { normalized: true });
    return !!(c?.confident && c.score >= min && ![].concat(flow.trigger || []).includes(c.id));
  }
}

// idioma da mensagem por palavras frequentes (custo zero). Retorna null se não der para saber.
const LANG_WORDS = {
  en: /\b(the|and|you|your|are|does|need|want|how|what|when|where|hi|hello|hey|please|thanks|thank|can|my|for|with|job|help|ship|have|price|size|is it|do you|i am|i'm)\b/g,
  es: /\b(el|los|las|hola|gracias|necesito|quiero|tengo|puedo|usted|cuanto|cuanta|cuando|donde|trabajo|ayuda|soy|estoy|tienen|hay|bolsos|precio|envian|zapatos|zapatillas|talla|buenas|buenos|senor|senora|porfa|vale)\b/g,
  pt: /\b(voce|voces|vc|vcs|eu|preciso|quero|tenho|oi|ola|obrigad[oa]|posso|com|nao|sim|esta|sou|qual|quanto|onde|tem|que|como|pra|para|bom|boa|dia|tarde|noite|gostaria|um|uma|meu|minha|ta|tudo|bem|aceita|entrega|manda|foto)\b/g,
};
// a língua padrão da marca só é trocada com evidência clara (evita "como funciona" virar espanhol)
export function detectLang(norm, allowed, lang0 = allowed?.[0]) {
  if (!allowed || allowed.length < 2) return null;
  const n = {};
  for (const l of allowed) n[l] = (String(norm).match(LANG_WORDS[l] || /$^/g) || []).length;
  let best = null, bestN = 0;
  for (const l of allowed) if (l !== lang0 && n[l] > bestN) { best = l; bestN = n[l]; }
  const base = n[lang0] || 0;
  if (best && ((bestN >= 1 && base === 0) || (bestN >= 3 && bestN > 2 * base))) return best;
  if (base >= 1 && base >= bestN) return lang0;
  return null;
}
