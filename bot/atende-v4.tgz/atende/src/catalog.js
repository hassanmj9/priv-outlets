// Catálogo: carrega de uma URL (JSON) ou arquivo, extrai entidades da pergunta
// (categoria, cor, gênero, marca, faixa de preço, tamanho) e busca sem custo.
import fs from 'node:fs';
import { stripAccents } from './normalize.js';

const DEF_ENT = {
  categorias: {
    bolsa: ['bolsa', 'bolsas', 'bolsinha', 'bag', 'bauletto', 'tiracolo', 'transversal', 'shoulder'],
    tenis: ['tenis', 'tennis', 'sneaker', 'sneakers', 'americas cup', 'america cup', 'americas'],
    sapato: ['sapato', 'sapatos', 'social', 'mocassim', 'sapatenis', 'oxford', 'derby', 'scarpin'],
    sandalia: ['sandalia', 'sandalias', 'rasteira', 'chinelo', 'salto'],
    bota: ['bota', 'botas', 'coturno', 'botinha'],
    carteira: ['carteira', 'carteiras', 'porta cartao', 'porta cartoes', 'portacartao', 'porta-cartao', 'cartoes', 'porta moedas', 'money clip'],
    'acessorio couro': ['agenda', 'agendas', 'porta chaves', 'chaveiro', 'porta documentos', 'organizador', 'porta passaporte'],
    necessaire: ['necessaire', 'necessaires', 'nessesaire', 'necesser', 'estojo', 'pochete', 'clutch'],
    cinto: ['cinto', 'cintos', 'cinta'],
    gorro: ['gorro', 'gorros', 'touca', 'toucas', 'beanie'],
    roupa: ['roupa', 'roupas', 'camiseta', 'camisetas', 'camisa', 'blusa', 'moletom', 'moletons', 'calca', 'calcas', 'jaqueta', 'jaquetas', 'casaco', 'casacos', 'terno', 'ternos', 'polo', 'blazer', 'suit', 'tshirt', 'camisa polo'],
    perfume: ['perfume', 'perfumes', 'colonia', 'fragrancia', 'fragancia', 'eau de toilette', 'eau de parfum', 'edt', 'edp', 'cheiroso'],
  },
  cores: {
    preto: ['Nero'], preta: ['Nero'], negro: ['Nero'], black: ['Nero'],
    branco: ['Bianco'], branca: ['Bianco'], white: ['Bianco'],
    marrom: ['Bruciato', 'Moro', 'Caffe', 'Cacao', 'Tabacco'], marron: ['Bruciato', 'Moro', 'Caffe', 'Cacao', 'Tabacco'], brown: ['Bruciato', 'Moro', 'Caffe', 'Cacao', 'Tabacco'],
    caramelo: ['Caramel', 'Sughero'], cafe: ['Caffe'], cacau: ['Cacao'], chocolate: ['Cacao', 'Moro'], tabaco: ['Tabacco'], conhaque: ['Bruciato', 'Tabacco'],
    prata: ['Argento'], prateado: ['Argento'], silver: ['Argento'],
    verde: ['Alloro', 'Army', 'Militare'], militar: ['Army', 'Militare'],
    cinza: ['Grigio', 'Antracite'], grafite: ['Antracite'], chumbo: ['Antracite'],
    azul: ['Bleu', 'Blu Aperto'], marinho: ['Bleu'],
    vermelho: ['Rosso', 'Scarlatto', 'Cerise'], vermelha: ['Rosso', 'Scarlatto', 'Cerise'], cereja: ['Cerise'], vinho: ['Cerise', 'Scarlatto'],
    bege: ['Mastice', 'Argilla'], nude: ['Mastice', 'Argilla'], areia: ['Argilla', 'Mastice'],
    cobre: ['Rame'], laranja: ['Rame'], bronze: ['Bronzo'], dourado: ['Bronzo'], terracota: ['Cotto'],
    // nomes italianos também valem
    nero: ['Nero'], bianco: ['Bianco'], bruciato: ['Bruciato'], moro: ['Moro'], caffe: ['Caffe'], cacao: ['Cacao'], tabacco: ['Tabacco'],
    caramel: ['Caramel'], sughero: ['Sughero'], argento: ['Argento'], alloro: ['Alloro'], army: ['Army'], militare: ['Militare'],
    grigio: ['Grigio'], antracite: ['Antracite'], bleu: ['Bleu'], rosso: ['Rosso'], scarlatto: ['Scarlatto'], cerise: ['Cerise'],
    mastice: ['Mastice'], argilla: ['Argilla'], rame: ['Rame'], bronzo: ['Bronzo'], cotto: ['Cotto'], ebano: ['Ebano'],
  },
  generos: {
    feminino: ['feminino', 'feminina', 'femininos', 'femininas', 'mulher', 'mulheres', 'ela', 'esposa', 'namorada', 'mae', 'filha', 'senhora', 'dama', 'woman', 'women'],
    masculino: ['masculino', 'masculina', 'masculinos', 'homem', 'homens', 'ele', 'marido', 'namorado', 'pai', 'senhor', 'man', 'men'],
    infantil: ['infantil', 'crianca', 'criancas', 'kids', 'filho pequeno', 'bebe', 'menino', 'menina'],
  },
  marcas: {
    Prada: ['prada', 'linea rossa', 'prada sport'], 'Miu Miu': ['miu miu', 'miumiu', 'miu'],
    Gucci: ['gucci', 'guci'], 'Hugo Boss': ['hugo boss', 'boss', 'hugo'], 'Dolce&Gabbana': ['dolce', 'gabbana', 'd&g', 'dg', 'dolce gabbana', 'light blue'],
    Mugler: ['mugler', 'thierry mugler', 'angel'], Montblanc: ['montblanc', 'mont blanc'], 'Ralph Lauren': ['ralph lauren', 'ralph', 'polo ralph'], Victorinox: ['victorinox', 'swiss army'],
  },
};

const STOP = new Set('a o os as de da do das dos e em um uma uns umas para pra pro por com sem que qual quais tem voce voces me manda mandar ver quero queria gostaria preciso saber sobre isso esse essa este esta tem ai la aqui seu sua meu minha mais menos muito ja so mesmo ainda bom boa dia tarde noite oi ola tudo bem fotos foto valor preco quanto custa custo disponivel disponiveis modelo modelos opcao opcoes'.split(' '));

function fold(s) { return stripAccents(String(s || '').toLowerCase()).replace(/[^a-z0-9& ]/g, ' ').replace(/\s+/g, ' ').trim(); }

// Tamanho pedido x grade da peça: roupa BR->internacional (GG=XL, P=S…) e calçado BR->numeração inglesa (n-33)
const CLOTH = { PP: ['XS', 'PP'], P: ['S', 'P'], M: ['M'], G: ['L', 'G'], GG: ['XL', 'GG'], XG: ['XXL', 'XG'], XGG: ['XXL', 'XGG'], EG: ['XXL', 'EG'], XS: ['XS', 'PP'], S: ['S', 'P'], L: ['L', 'G'], XL: ['XL', 'GG'], XXL: ['XXL', 'XG', 'EG'] };
export function sizeMatch(x, want) {
  const W = String(want || '').toUpperCase();
  const sizes = (x.tamanhos || []).map((t) => String(t).toUpperCase());
  if (!W || !sizes.length) return null;
  if (sizes.includes(W)) return { tam: W, conv: null };
  const suf = sizes.find((z) => new RegExp(`^${W.replace('.', '\\.')}[A-Z]$`).test(z)); // terno 50 -> 50R
  if (suf) return { tam: suf, conv: null };
  if (CLOTH[W]) { const t = sizes.find((z) => CLOTH[W].includes(z)); return t ? { tam: t, conv: `${W} = ${t}` } : null; }
  const n = +W;
  if (n >= 33 && n <= 48 && sizes.every((z) => +z > 0 && +z <= 14)) {
    const uk = String(n - 33);
    const t = sizes.find((z) => z === uk || z === `${uk}.5`);
    return t ? { tam: t, conv: `${n} BR ≈ ${t} na numeração inglesa`, uk: true } : null;
  }
  return null;
}

// peças pedidas pelo nome (filtra pelo nome, não pela descrição/material)
const PECAS = ['terno', 'moletom', 'polo', 'camiseta', 'camisa', 'jaqueta', 'casaco', 'sapatenis', 'agenda', 'pasta', 'bermuda', 'blazer', 'sandalia', 'mocassim', 'bota', 'nécessaire', 'necessaire', 'gorro', 'cinto', 'mochila', 'porta cartao', 'porta cartoes', 'carteira'];

export class Catalog {
  constructor(cfg = {}, entities = {}) {
    this.cfg = cfg;
    this.items = [];
    this.loadedAt = null;
    this.ent = mergeEnt(DEF_ENT, entities || {});
  }

  async load() {
    let data;
    if (this.cfg.file) data = JSON.parse(fs.readFileSync(this.cfg.file, 'utf8'));
    else if (this.cfg.url) {
      const r = await fetch(this.cfg.url, { headers: { 'cache-control': 'no-cache' } });
      if (!r.ok) throw new Error('catalogo HTTP ' + r.status);
      data = await r.json();
    } else data = { itens: [] };
    const itens = data.itens || data.items || data;
    this.items = itens.filter((x) => (x.estoque ?? 1) > 0).map((x) => ({ ...x, _t: fold([x.nome, x.titulo, x.marca, x.cor, x.cor_pt, x.categoria, x.genero, x.material, x.modelo, x.conc, x.ml ? x.ml + 'ml' : '', x.fora_de_linha ? 'fora de linha colecionavel raro' : '', x.linea_rossa ? 'linea rossa' : ''].join(' ')) }));
    this.byId = new Map(this.items.map((x) => [x.id, x]));
    const df = new Map();
    for (const it of this.items) for (const w of new Set(it._t.split(' '))) df.set(w, (df.get(w) || 0) + 1);
    this.idf = new Map([...df].map(([w, c]) => [w, Math.log(1 + this.items.length / c)]));
    this.loadedAt = new Date().toISOString();
    return this.items.length;
  }

  startAutoRefresh() {
    const min = this.cfg.refresh_min || 30;
    if (!this.cfg.url) return;
    setInterval(() => this.load().catch((e) => console.error('[catalogo]', e.message)), min * 60e3).unref();
  }

  get(id) { return this.byId?.get(id); }
  // acha a peça por um link do site (/produto/<slug> ou /#p/<id>)
  byLink(text) {
    const t = String(text || '');
    const id = t.match(/#p\/([A-Za-z0-9-]+)/)?.[1];
    if (id && this.byId?.get(id)) return this.byId.get(id);
    const slug = t.match(/\/produto\/([a-z0-9-]+)/i)?.[1];
    if (!slug) return null;
    return this.items.find((x) => x.link?.endsWith('/' + slug)) || this.items.find((x) => slug.startsWith(x.link?.split('/').pop() || '\u0000')) || null;
  }

  // Extrai entidades de um texto já normalizado
  entities(norm) {
    const s = ' ' + fold(norm) + ' ';
    const has = (w) => s.includes(' ' + w + ' ');
    const out = { categorias: [], cores: [], genero: null, marcas: [], preco_max: null, preco_min: null, ordenar: null, tamanho: null, fora_de_linha: false };
    for (const [cat, ws] of Object.entries(this.ent.categorias)) if (ws.some((w) => has(fold(w)))) out.categorias.push(cat);
    for (const [cor, codes] of Object.entries(this.ent.cores)) if (has(cor)) { out.cor_txt ||= cor; for (const c of codes) if (!out.cores.includes(c)) out.cores.push(c); }
    // "ela"/"ele"/"senhor(a)" sozinhos são pronomes/tratamento, não gênero da peça ("quero ver ela")
    for (const [g, ws] of Object.entries(this.ent.generos)) if (ws.some((w) => !/^(ela|ele|senhor|senhora|dela|dele)$/.test(fold(w)) && has(fold(w)))) { out.genero = g; break; }
    for (const [m, ws] of Object.entries(this.ent.marcas)) if (ws.some((w) => has(fold(w)))) out.marcas.push(m);
    // preço: "ate 3 mil", "ate 3000", "menos de 500", "entre 1000 e 3000", "3k"
    const num = (t) => { const m = String(t).match(/^(\d+(?:\.\d+)?)(k|mil)?$/); if (!m) return null; let v = parseFloat(m[1]); if (m[2] || (s.includes(m[1] + ' mil'))) v *= 1000; return v; };
    const FILL = '(?:(?:uns|umas|um|uma|cerca de|mais ou menos|tipo|no maximo|uns reais|reais|r)\\s+)*';
    let m = s.match(new RegExp('(?:ate|abaixo de|menos de|no maximo|max|maximo|teto de|budget|orcamento de|gastar)\\s+' + FILL + '(\\d+(?:\\.\\d+)?(?:k)?)(\\s+mil)?'));
    if (m) { let v = num(m[1]); if (m[2]) v = parseFloat(m[1]) * 1000; out.preco_max = v; }
    m = s.match(/entre\s+(?:reais\s+)?(\d+(?:\.\d+)?k?)(\s+mil)?\s+e\s+(?:reais\s+)?(\d+(?:\.\d+)?k?)(\s+mil)?/);
    if (m) { let a = num(m[1]), b = num(m[3]); if (m[2]) a = parseFloat(m[1]) * 1000; if (m[4]) { b = parseFloat(m[3]) * 1000; if (a < 100) a *= 1000; } out.preco_min = Math.min(a, b); out.preco_max = Math.max(a, b); }
    m = s.match(new RegExp('(?:acima de|mais de|a partir de)\\s+' + FILL + '(\\d+(?:\\.\\d+)?k?)(\\s+mil)?'));
    if (m) { let v = num(m[1]); if (m[2]) v = parseFloat(m[1]) * 1000; out.preco_min = v; }
    if (/\b(mais barat|menor preco|mais em conta|economic|baratinh|barato)/.test(s)) out.ordenar = 'asc';
    if (/\b(mais car|mais exclusiv|top de linha)/.test(s)) out.ordenar = 'desc';
    m = s.match(/\b(?:tamanho|numero|num|n|tam|size|talla|uso|visto)\s*(\d{1,3}(?:\.5)?|pp|p|m|g|gg|xg|xgg|eg|xs|s|l|xl|xxl)\b/);
    if (m) out.tamanho = m[1].toUpperCase();
    // "calça 30", "calço 41": é tamanho de calçado, não a peça calça
    m = s.match(/\b(?:calca|calco|calcam|calcas)\s+(?:numero\s+)?(\d{2}(?:\.5)?)\b/);
    if (m) { out.tamanho = m[1]; out.categorias = out.categorias.filter((c) => c !== 'roupa'); }
    // "no 42", "no GG", "cinto 115" quando já há categoria com grade
    if (!out.tamanho && out.categorias.length) { m = s.match(/\b(?:no|na|em|de|tem)\s+(\d{2,3}(?:\.5)?|pp|p|m|g|gg|xg|xs|s|l|xl|xxl)\b(?!\s*(?:mil|reais|ml))/); if (m && !(m[1].length <= 2 && /^(m|g|p|s|l)$/.test(m[1]) && !/\btem\s+[pmgsl]\b|\bno\s+[pmgsl]\b/.test(s))) out.tamanho = m[1].toUpperCase(); }
    if (/\b(fora de linha|descontinuad|raro|rara|colecion|antig)/.test(s)) out.fora_de_linha = true;
    return out;
  }

  hasEntities(e) { return e.categorias.length || e.marcas.length || e.cores.length || e.preco_max || e.preco_min || e.fora_de_linha; }

  // Busca: filtros duros + pontuação por palavras raras
  search(norm, e = this.entities(norm), limit = 5) {
    let list = this.items;
    const cats = e.categorias.filter((c) => c !== 'roupa' || true);
    if (cats.length) list = list.filter((x) => cats.includes(x.categoria) || (cats.includes('roupa') && x.categoria === 'roupa') || (cats.includes('carteira') && x.categoria === 'acessorio couro' && /porta|carteira/.test(x._t)));
    if (e.marcas.length) list = list.filter((x) => e.marcas.includes(x.marca) || e.marcas.some((m) => x._t.includes(fold(m))));
    if (e.cores.length) {
      const f = list.filter((x) => x.cor && e.cores.some((c) => x.cor.split(/\s*\+\s*/).includes(c)));
      list = f;
    }
    if (e.genero) {
      const g = list.filter((x) => x.genero === e.genero || x.genero === 'unissex' || (e.genero === 'masculino' && x.genero === 'masculino'));
      if (g.length) list = g;
    }
    if (e.fora_de_linha) list = list.filter((x) => x.fora_de_linha);
    if (e.preco_max) list = list.filter((x) => x.preco <= e.preco_max);
    if (e.preco_min) list = list.filter((x) => x.preco >= e.preco_min);
    if (e.tamanho) {
      const t = list.filter((x) => sizeMatch(x, e.tamanho));
      if (t.length || list.some((x) => (x.tamanhos || []).length)) list = t;
    }
    // peça citada pelo nome ("terno", "moletom"): só itens com a palavra no nome
    const fq = ' ' + fold(norm) + ' ';
    const peca = PECAS.find((w) => fq.includes(' ' + fold(w) + ' ') || fq.includes(' ' + fold(w) + 's '));
    if (peca) { const byName = list.filter((x) => (' ' + fold(x.nome) + ' ').includes(' ' + fold(peca))); if (byName.length) list = byName; }
    // pontuação textual (nome do modelo: "bauletto", "flora", "guilty", "bottled", "americas")
    const qw = fold(norm).split(' ').filter((w) => w.length > 2 && !STOP.has(w));
    const scored = list.map((x) => {
      let sc = 0;
      const nm = fold(x.nome || '');
      // palavra no nome pesa mais que no material/descrição (a Polo de "moletom de algodão" não passa na frente do moletom)
      for (const w of qw) if (nm.includes(w)) sc += 2 * (this.idf.get(w) || 1); else if (x._t.includes(w)) sc += 0.5 * (this.idf.get(w) || 1);
      return { x, sc };
    });
    if (!this.hasEntities(e)) {
      // sem filtros: só vale se alguma palavra rara bateu forte
      const strong = scored.filter((s) => s.sc >= 3).sort((a, b) => b.sc - a.sc);
      return strong.slice(0, limit).map((s) => s.x);
    }
    if (e.ordenar === 'asc') scored.sort((a, b) => a.x.preco - b.x.preco);
    else if (e.ordenar === 'desc') scored.sort((a, b) => b.x.preco - a.x.preco);
    // com teto de preço ("até 3 mil"), mostra primeiro o que chega mais perto do orçamento
    else scored.sort((a, b) => b.sc - a.sc || (e.preco_max ? b.x.preco - a.x.preco : a.x.preco - b.x.preco));
    return scored.slice(0, limit).map((s) => s.x);
  }

  pecaIn(norm) { const fq = ' ' + fold(norm) + ' '; return PECAS.find((w) => fq.includes(' ' + fold(w) + ' ') || fq.includes(' ' + fold(w) + 's ')) || null; }

  count(e, norm = '') { return this.search(norm, e, 9999).length; }

  // mesmo modelo em outras cores (pelo código do modelo ou pelo nome sem a cor)
  siblings(x) {
    const base = (y) => fold(String(y.nome || '').replace(new RegExp(`\\s*${(y.cor_pt || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*$`, 'i'), ''));
    const b = base(x);
    return this.items.filter((y) => y.id !== x.id && ((x.modelo && y.modelo === x.modelo) || (b && base(y) === b)));
  }

  // Linha compacta para o LLM (economiza tokens)
  static line(x) {
    const extra = x.tipo === 'perfume' ? `${x.ml}ml ${x.conc}${x.fora_de_linha ? ' fora de linha' : ''}` : `${x.cor_pt || x.cor || ''}${(x.tamanhos || []).length ? ' tam ' + x.tamanhos.join('/') : ''}`;
    return `${x.id}|${x.nome}|${extra}|R$${x.preco}${x.preco_de && x.preco_de > x.preco ? ' (de ' + x.preco_de + ', -' + Math.round((1 - x.preco / x.preco_de) * 100) + '%)' : ''}`;
  }
}

function mergeEnt(base, extra) {
  const out = JSON.parse(JSON.stringify(base));
  for (const k of ['categorias', 'cores', 'generos', 'marcas']) {
    for (const [kk, v] of Object.entries(extra[k] || {})) {
      const key = k === 'cores' ? fold(kk) : kk;
      const vals = (Array.isArray(v) ? v : [v]);
      if (k === 'cores') out[k][key] = Array.from(new Set([...(out[k][key] || []), ...vals]));
      else out[k][key] = Array.from(new Set([...(out[k][key] || []), ...vals.map(fold)]));
    }
  }
  return out;
}

export function fmtBRL(v) {
  return 'R$ ' + Math.round(v).toLocaleString('pt-BR');
}
