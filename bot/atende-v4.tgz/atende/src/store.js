// Estado das conversas, cache de respostas e métricas, em arquivos JSON (sem banco).
import fs from 'node:fs';
import path from 'node:path';

export class Store {
  constructor(dir) {
    this.dir = dir;
    fs.mkdirSync(dir, { recursive: true });
    this.convFile = path.join(dir, 'conversas.json');
    this.cacheFile = path.join(dir, 'cache_respostas.json');
    this.statsFile = path.join(dir, 'metricas.json');
    this.learnFile = path.join(dir, 'aprender.jsonl');
    this.conv = this.read(this.convFile, {});
    this.cache = this.read(this.cacheFile, {});
    this.stats = this.read(this.statsFile, { dias: {} });
    this.dirty = false;
    this.timer = setInterval(() => this.flush(), 5000);
    this.timer.unref?.();
  }

  read(f, def) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return def; } }

  flush() {
    if (!this.dirty) return;
    this.dirty = false;
    // mantém só as 3.000 conversas mais recentes
    const ids = Object.keys(this.conv);
    if (ids.length > 3000) {
      ids.sort((a, b) => (this.conv[a].ts || 0) - (this.conv[b].ts || 0));
      for (const id of ids.slice(0, ids.length - 3000)) delete this.conv[id];
    }
    fs.writeFileSync(this.convFile, JSON.stringify(this.conv));
    fs.writeFileSync(this.cacheFile, JSON.stringify(this.cache));
    fs.writeFileSync(this.statsFile, JSON.stringify(this.stats));
  }

  get(key, brand) {
    if (!this.conv[key]) this.conv[key] = { brand, stage: null, score: 0, hist: [], products: [], focus: null, llm: 0, cost: 0, handoff: false, msgs: 0, tiers: {}, ts: Date.now() };
    return this.conv[key];
  }

  touch() { this.dirty = true; }

  day() { return new Date().toISOString().slice(0, 10); }

  count(brand, tier, cost = 0, usage = null) {
    const d = this.day();
    const s = (this.stats.dias[d] ||= {});
    const b = (s[brand] ||= { mensagens: 0, tiers: {}, custo_usd: 0, llm_chamadas: 0, tokens_in: 0, tokens_out: 0, cache_read: 0, conversas: 0, transbordos: 0 });
    b.mensagens++;
    b.tiers[tier] = (b.tiers[tier] || 0) + 1;
    if (cost) b.custo_usd = +(b.custo_usd + cost).toFixed(6);
    if (usage) { b.llm_chamadas++; b.tokens_in += usage.input || 0; b.tokens_out += usage.output || 0; b.cache_read += usage.cache_read || 0; }
    this.dirty = true;
  }

  bump(brand, field) { const d = this.day(); const s = (this.stats.dias[d] ||= {}); const b = (s[brand] ||= { mensagens: 0, tiers: {}, custo_usd: 0, llm_chamadas: 0, tokens_in: 0, tokens_out: 0, cache_read: 0, conversas: 0, transbordos: 0 }); b[field] = (b[field] || 0) + 1; this.dirty = true; }

  spentToday() {
    const s = this.stats.dias[this.day()] || {};
    return Object.values(s).reduce((a, b) => a + (b.custo_usd || 0), 0);
  }

  cacheGet(k) {
    const e = this.cache[k];
    if (!e) return null;
    if (Date.now() - e.ts > 14 * 864e5) { delete this.cache[k]; return null; }
    e.hits = (e.hits || 0) + 1; this.dirty = true;
    return e;
  }

  cacheSet(k, v) { this.cache[k] = { ...v, ts: Date.now(), hits: 0 }; this.dirty = true; }

  learn(rec) { fs.appendFile(this.learnFile, JSON.stringify({ ts: new Date().toISOString(), ...rec }) + '\n', () => {}); }
}
