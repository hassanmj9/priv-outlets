// Servidor do bot: recebe o webhook de Agent Bot do Chatwoot, agrupa mensagens
// seguidas do cliente (debounce), escolhe a marca pela caixa de entrada e responde.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Brand } from './brain.js';
import { Chatwoot } from './chatwoot.js';
import { Store } from './store.js';
import { isHumanReply, onHuman, onIncoming, resumeReason, onResume, RESUME_NOTE } from './control.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
loadEnv(path.join(ROOT, '.env'));
if (process.env.ENV_EXTRA) loadEnv(process.env.ENV_EXTRA); // .env de uma instalação anterior, lido no lugar
const CFG = JSON.parse(fs.readFileSync(process.env.ATENDE_CONFIG || path.join(ROOT, 'config.json'), 'utf8'));
// aceita os nomes de variável da v3 e de outras instalações (migração sem editar .env)
const env = (...names) => { for (const n of names) { if (n instanceof RegExp) { const k = Object.keys(process.env).find((x) => n.test(x) && process.env[x]); if (k) return process.env[k]; } else if (process.env[n]) return process.env[n]; } return undefined; };
const PORT = +(process.env.PORT || CFG.port || 3100);
const SECRET = env('HOOK_SECRET', 'WEBHOOK_SECRET', 'BOT_SECRET', 'SECRET') || CFG.hook_secret;
const DEBOUNCE = +(process.env.DEBOUNCE_MS || CFG.debounce_ms || 2500);
if (!SECRET) { console.error('[atende] defina HOOK_SECRET no .env'); process.exit(1); }

const store = new Store(process.env.DATA_DIR || path.join(ROOT, 'data'));
const cw = new Chatwoot({
  url: env('CHATWOOT_URL', 'CHATWOOT_BASE_URL', 'CHATWOOT_API_URL') || CFG.chatwoot_url,
  accountId: env('CHATWOOT_ACCOUNT_ID', 'ACCOUNT_ID') || CFG.chatwoot_account_id,
  token: env('CHATWOOT_BOT_TOKEN', 'CHATWOOT_TOKEN', 'CHATWOOT_API_TOKEN', 'CHATWOOT_ACCESS_TOKEN', 'AGENT_BOT_TOKEN', 'BOT_TOKEN', /^(CHATWOOT|CW)_.*TOKEN$/),
});
const llmCfg = {
  provider: process.env.LLM_PROVIDER || CFG.llm?.provider || 'anthropic',
  model: process.env.LLM_MODEL || CFG.llm?.model || 'claude-haiku-4-5',
  apiKey: env('LLM_API_KEY', 'ANTHROPIC_API_KEY', 'CLAUDE_API_KEY', 'ANTHROPIC_KEY'),
  baseUrl: process.env.LLM_BASE_URL || CFG.llm?.base_url,
  maxTokens: CFG.llm?.max_tokens || 220,
};

const brands = [];
const byInbox = new Map();
for (const b of CFG.marcas) {
  const brand = new Brand({ dir: path.resolve(ROOT, b.pacote), cfg: { brand: b.marca, ...b }, chatwoot: cw, store, llmCfg: { ...llmCfg, ...(b.llm || {}) }, catalogCfg: b.catalogo });
  brands.push(brand);
  // caixas: [1, 2] ou [{ "id": 5, "sub": "desgolpe" }] (sub-marca: textos say_<sub> e intenções da sub-marca)
  for (const c of b.caixas || []) byInbox.set(+(c?.id ?? c), { brand, sub: c?.sub || null });
}
await Promise.all(brands.map((b) => b.init().catch((e) => console.error('[init]', b.id, e.message))));
console.log(`[atende] ${brands.map((b) => `${b.id}: ${b.intents.length} intenções, ${b.catalog?.items.length ?? 0} peças`).join(' | ')}`);

const pending = new Map(); // conversa -> {texts, atts, timer, ctx}
const seen = new Map(); // id da mensagem -> hora (o Chatwoot reenvia em timeout)
const resuming = new Map(); // conversa -> retomada em curso (a resposta espera a nota e o status)

function onEvent(ev) {
  if (ev.event !== 'message_created') return;
  const conv = ev.conversation || {};
  const hit = byInbox.get(+(ev.inbox?.id || conv.inbox_id));
  const brand = hit?.brand || brands[0];
  if (!brand || conv.id == null) return;
  const key = `${brand.id}:${conv.id}`;
  const now = Date.now();
  // alguém da equipe respondeu o cliente: equipe no controle, bot fica quieto
  if (isHumanReply(ev)) {
    const st = store.get(key, brand.id);
    st.key ||= key; st.conv ||= conv.id;
    onHuman(st, now); store.touch();
    const p = pending.get(key); if (p) { clearTimeout(p.timer); pending.delete(key); }
    if (conv.status === 'pending') cw.status(conv.id, 'open').catch((e) => console.error('[equipe]', e.message));
    return;
  }
  if (ev.message_type !== 'incoming' || ev.private) return;
  if (ev.sender?.type && ev.sender.type !== 'contact') return;
  if (ev.id) { if (seen.has(ev.id)) return; seen.set(ev.id, now); if (seen.size > 5000) for (const [k, t] of seen) { if (now - t > 36e5) seen.delete(k); else break; } }
  const st = store.get(key, brand.id);
  st.key ||= key; st.conv ||= conv.id;
  if (conv.status && conv.status !== 'pending') {
    // equipe no controle: o bot só volta se ninguém respondeu em 2 h ou se o cliente voltou depois de 24 h
    const why = resumeReason(st, conv, now);
    onIncoming(st, now, conv); store.touch();
    if (!why) return;
    if (why !== 'retomada') {
      onResume(st, why, now);
      store.bump(brand.id, 'retomadas');
      console.log(`[retomada] ${key} ${why}`);
      const job = cw.note(conv.id, RESUME_NOTE[why]).then(() => cw.status(conv.id, 'pending')).catch((e) => console.error('[retomada]', e.message));
      resuming.set(key, job); job.finally(() => setTimeout(() => resuming.delete(key), 60e3).unref?.());
    }
  } else { onIncoming(st, now, conv); store.touch(); }
  const p = pending.get(key) || { texts: [], atts: [], ctx: { key, conv: conv.id, nome: ev.sender?.name, canal: conv.channel || ev.inbox?.channel_type || '', sub: hit?.sub || null } };
  const ref = ev.content_attributes?.referral || ev.additional_attributes?.referral || conv.additional_attributes?.referral;
  if (ref) p.ctx.referral = { titulo: ref.headline || ref.title || '', texto: ref.body || '', url: ref.source_url || ref.url || '', tipo: ref.source_type || '' };
  if (ev.content) p.texts.push(ev.content);
  for (const a of ev.attachments || []) p.atts.push({ type: a.file_type || 'file', url: a.data_url });
  clearTimeout(p.timer);
  p.first ||= now;
  const wait = now - p.first > 8000 ? 0 : DEBOUNCE;
  p.timer = setTimeout(async () => {
    pending.delete(key);
    await resuming.get(key);
    brand.turn({ ...p.ctx, text: p.texts.join('\n'), attachments: p.atts }).catch((e) => console.error('[turno]', e));
  }, wait);
  pending.set(key, p);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  if (req.method === 'GET' && url.pathname === '/health') {
    return json(res, { ok: true, versao: 4, config: { chatwoot: !!cw.token, ia: !!llmCfg.apiKey, modelo: llmCfg.model }, marcas: brands.map((b) => ({ id: b.id, intencoes: b.intents.length, catalogo: b.catalog?.items.length ?? 0, atualizado: b.catalog?.loadedAt })), gasto_hoje_usd: +store.spentToday().toFixed(4), conversas: Object.keys(store.conv).length });
  }
  if (req.method === 'GET' && url.pathname === `/stats/${SECRET}`) return json(res, store.stats);
  if (req.method === 'POST' && url.pathname === `/hook/${SECRET}`) {
    let body = '';
    req.on('data', (c) => { body += c; if (body.length > 2e6) req.destroy(); });
    req.on('end', () => { json(res, { ok: true }); try { onEvent(JSON.parse(body)); } catch (e) { console.error('[hook]', e.message); } });
    return;
  }
  res.writeHead(404).end();
});
server.listen(PORT, () => console.log(`[atende] ouvindo na porta ${PORT}`));
// lembretes com consentimento (a cada 10 min)
setInterval(() => { for (const b of brands) b.runFollowups().catch((e) => console.error('[lembretes]', e.message)); }, 10 * 60e3).unref();
process.on('SIGTERM', () => { store.flush(); process.exit(0); });
process.on('SIGINT', () => { store.flush(); process.exit(0); });

function json(res, o) { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); }
function loadEnv(f) { try { for (const l of fs.readFileSync(f, 'utf8').split('\n')) { const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, ''); } } catch {} }
