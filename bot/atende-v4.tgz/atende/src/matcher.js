// Classificador de intenções sem custo: TF-IDF de n-gramas de caracteres + palavras,
// similaridade de cosseno contra os exemplos de cada intenção, com bônus de palavra-chave.
// Roda em milissegundos, sem rede e sem modelo.

function grams(text) {
  const feats = new Map();
  const add = (f, w = 1) => feats.set(f, (feats.get(f) || 0) + w);
  const words = text.split(' ').filter(Boolean);
  for (const w of words) {
    add('w:' + w, 1.5);
    const p = ` ${w} `;
    for (let n = 3; n <= 4; n++) {
      for (let i = 0; i + n <= p.length; i++) add(p.slice(i, i + n));
    }
  }
  for (let i = 0; i + 1 < words.length; i++) add('b:' + words[i] + '_' + words[i + 1], 1.2);
  return feats;
}

export class Matcher {
  constructor(intents, normalize) {
    this.normalize = normalize;
    this.intents = intents;
    const docs = [];
    for (const it of intents) {
      for (const ex of it.examples || []) {
        const n = normalize(ex);
        if (n) docs.push({ id: it.id, text: n, feats: grams(n) });
      }
      // o id e a descrição também ajudam
      if (it.desc) docs.push({ id: it.id, text: normalize(it.desc), feats: grams(normalize(it.desc)), weak: true });
    }
    const df = new Map();
    for (const d of docs) for (const f of d.feats.keys()) df.set(f, (df.get(f) || 0) + 1);
    const N = docs.length || 1;
    this.idf = new Map();
    for (const [f, c] of df) this.idf.set(f, Math.log(1 + N / c));
    for (const d of docs) d.vec = this.vectorize(d.feats);
    this.docs = docs;
    this.kw = new Map(intents.map((it) => [it.id, (it.keywords || []).map((k) => normalize(k)).filter(Boolean)]));
    // prioridade (desempate) e filtro opcional (ex.: intenções só de uma sub-marca)
    this.prio = new Map(intents.map((it) => [it.id, ((it.priority ?? 5) - 5) * 0.01]));
    this.allow = null;
    // exatos (frase normalizada idêntica a um exemplo)
    this.exact = new Map();
    for (const d of docs) if (!d.weak && !this.exact.has(d.text)) this.exact.set(d.text, d.id);
  }

  vectorize(feats) {
    const v = new Map();
    let norm = 0;
    for (const [f, tf] of feats) {
      const w = (1 + Math.log(tf)) * (this.idf.get(f) || Math.log(1 + (this.docs?.length || 1)));
      v.set(f, w);
      norm += w * w;
    }
    norm = Math.sqrt(norm) || 1;
    for (const [f, w] of v) v.set(f, w / norm);
    return v;
  }

  static cos(a, b) {
    let s = 0;
    const [x, y] = a.size < b.size ? [a, b] : [b, a];
    for (const [f, w] of x) {
      const o = y.get(f);
      if (o) s += w * o;
    }
    return s;
  }

  keywordHits(norm, id) {
    const words = ' ' + norm + ' ';
    let hits = 0;
    for (const k of this.kw.get(id) || []) {
      if (k.includes(' ')) { if (words.includes(' ' + k)) hits++; }
      else if (new RegExp(`\\b${k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`).test(norm)) hits++;
    }
    return hits;
  }

  // Retorna ranking [{id, score, sim, kw}] ordenado
  rank(text, { normalized = false } = {}) {
    const norm = normalized ? text : this.normalize(text);
    if (!norm) return [];
    const ex = this.exact.get(norm);
    const q = this.vectorize(grams(norm));
    const best = new Map();
    for (const d of this.docs) {
      const s = Matcher.cos(q, d.vec) * (d.weak ? 0.8 : 1);
      if (s > (best.get(d.id) || 0)) best.set(d.id, s);
    }
    const out = [];
    for (const it of this.intents) {
      if (this.allow && !this.allow(it)) continue;
      const sim = best.get(it.id) || 0;
      const kw = this.keywordHits(norm, it.id);
      let score = sim + Math.min(kw, 2) * 0.12 + (sim > 0.2 ? this.prio.get(it.id) || 0 : 0);
      if (ex === it.id) score = Math.max(score, 1.2);
      out.push({ id: it.id, score, sim, kw });
    }
    out.sort((a, b) => b.score - a.score);
    return out;
  }

  // Decide: retorna {id, score, confident} ou null
  classify(text, opts = {}) {
    const r = this.rank(text, opts);
    if (!r.length) return null;
    const [a, b] = r;
    const margin = a.score - (b ? b.score : 0);
    const wordCount = (opts.normalized ? text : this.normalize(text)).split(' ').length;
    const hi = opts.threshold ?? 0.6;
    let confident = (a.score >= hi && margin >= 0.04) || (a.kw > 0 && a.score >= 0.45 && margin >= 0.08);
    // frases muito longas com várias perguntas: menos confiança
    if (wordCount > 25 && a.score < 0.8) confident = false;
    return { id: a.id, score: +a.score.toFixed(3), margin: +margin.toFixed(3), confident, second: b ? b.id : null };
  }
}
