// Cérebro do atendimento: decide, para cada mensagem, a camada mais barata que resolve.
//   regra (botão/intenção pronta) -> contexto (preço/tamanho/foto da peça em foco) -> catálogo
//   -> cache de respostas -> LLM com contexto mínimo -> transbordo humano.
import fs from 'node:fs';
import path from 'node:path';
import { makeNormalizer, ORDINAIS } from './normalize.js';
import { Matcher } from './matcher.js';
import { Catalog, fmtBRL, sizeMatch } from './catalog.js';
import { LLM, parseJSON } from './llm.js';
import { btnTitle } from './chatwoot.js';
import { Flows, V, detectLang, yesNoButton } from './flows.js';

const readJSON = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
const readTxt = (f) => { try { return fs.readFileSync(f, 'utf8'); } catch { return ''; } };
const hash = (s) => { let h = 2166136261; for (const c of String(s)) h = Math.imul(h ^ c.charCodeAt(0), 16777619); return h >>> 0; };

const saudacao = (tz = 'America/Sao_Paulo') => { const h = +new Intl.DateTimeFormat('en-US', { hour: 'numeric', hour12: false, timeZone: tz }).format(new Date()) % 24; return h >= 5 && h < 12 ? 'Bom dia' : h >= 12 && h < 18 ? 'Boa tarde' : 'Boa noite'; };
const GREET = /^(oi+|ola|ole|opa|bom dia|boa tarde|boa noite|boa|e ai|eai|hello|hi|hey|hola|buenas|buenos dias|buenas tardes|good morning|tudo bem|td bem|tudo bom)\b[\s,!.]*/;
const RX = {
  preco: /\b(preco|valor|quanto|custa|sai por|qual o valor|precos|valores|price|cuanto)\b/,
  tamanho: /\b(tamanho|tamanhos|numero|numeracao|tam|calca|calco|veste|serve|medida|medidas|size|talla)\b/,
  foto: /\b(foto|fotos|imagem|imagens|video|videos|mostra|mostrar|manda|ver ela|ver ele|photo|pictures|fotito)\b/,
  link: /\b(link|site|comprar|compro|onde compra|como compra|pagina)\b/,
  qualquer: /\b(qualquer|qualquer uma|qualquer um|tanto faz|todas|todos|as duas|os dois|as tres|todas elas)\b/,
  mais: /\b(mais opcoes|outras opcoes|outros modelos|mais modelos|tem mais|mais alguma|outra opcao|proximas|ver mais|so isso|so esses|so essas|so esse|so essa|nao tem nenhuma|nao tem nenhum|nao tem outra|nao tem outro|tem outras|tem outros)\b/,
  fechar: /^(?:ta bom |ok |entao |beleza |blz |show |perfeito )?(?:quero (?:comprar|levar|esse|essa|ele|ela|o |a |\d)|vou levar|vou querer|fecha|fechado|fechou|pode fechar|manda o pix|me passa o pix|passa o pix|qual a chave|quero sim|eu quero)\b/,
  pixLink: /\b(manda|mandar|me passa|passa|envia)\s+(o |a )?(pix|chave|link de pagamento|link pra pagar|conta|boleto|dados)\b/,
  diferenca: /\b(diferenca|diferente|diferencas|qual (a )?melhor|compara|comparar|qual e mais bonit[oa]|qual voce indica|qual recomenda)\b/,
  extremo: /\b(a|o) (menor|maior|mais barat[oa]|mais car[oa])\b|^(menor|maior|mais barat[oa]|mais car[oa])$/,
  outraCor: /\b(outra cor|outras cores|mais cores|quais cores|que cores|tem em outra|tem de outra|tem na cor|tem em|tem de|vem em|existe em)\b/,
  essa: /\b(essa|esse|dessa|desse|igual|parecid[oa]|tem essa|tem esse|essa ai|esse ai|da foto|dessa foto)\b/,
  cep: /\b(\d{5})-?(\d{3})\b/,
  sim: /^(sim|quero|pode|claro|manda|isso|ok|beleza|bora|yes|si|por favor|pode ser|quero sim|manda sim)$/,
  nao: /^(nao|agora nao|depois|so olhando|obrigado nao|no)$/,
};

export class Brand {
  constructor({ dir, cfg, chatwoot, store, llmCfg, catalogCfg }) {
    this.dir = dir;
    this.cfg = cfg;
    this.id = cfg.brand;
    this.b = readJSON(path.join(dir, 'brand.json'), {});
    const ints = readJSON(path.join(dir, 'intents.json'), { intents: [] });
    this.intents = ints.intents || [];
    // ajustes.json: camada editável por cima do pacote (exemplos novos, intenções novas, atalhos por regex)
    const aj = readJSON(path.join(dir, 'ajustes.json'), {});
    this.aj = aj;
    this.applyAjustes(aj);
    this.byId = new Map(this.intents.map((i) => [i.id, i]));
    this.flows = readJSON(path.join(dir, 'flows.json'), {});
    this.lang0 = this.b.idioma_padrao || ints.default_lang || 'pt';
    this.langs = [...new Set([this.lang0, ...(Array.isArray(this.b.idiomas) ? this.b.idiomas : ints.langs || [])])];
    this.kb = readTxt(path.join(dir, 'kb.md'));
    const sin = readJSON(path.join(dir, 'sinonimos.json'), {});
    this.normalize = makeNormalizer(sin.normalizacao || sin.abreviacoes || sin.sinonimos || {});
    this.matcher = new Matcher(this.intents, this.normalize);
    this.flowsR = new Flows(this.flows, { normalize: this.normalize, matcher: this.matcher, langs: this.langs.filter((l) => l !== this.lang0) });
    // pergunta de catálogo no meio de um fluxo ("tem bolsa preta?") encerra o fluxo e vai para a busca
    this.flowsR.offTopic = (norm) => { if (!this.catalog) return false; const e = this.catalog.entities(norm); return !!(e.categorias.length || e.marcas.length || (e.cores.length && /\b(tem|quero|mostra|manda)\b/.test(norm))); };
    this.guard = (this.b.guarda_saida?.padroes_bloqueados || []).map((r) => { try { return new RegExp(r, 'i'); } catch { return null; } }).filter(Boolean);
    this.catalog = catalogCfg ? new Catalog(catalogCfg, sin.entidades || sin.entities || {}) : null;
    this.cw = chatwoot;
    this.store = store;
    this.llm = new LLM(llmCfg || {});
    this.stages = this.b.funil?.etapas || ['1-novo-lead', '2-em-atendimento', '3-proposta-enviada', '4-aguardando-pagamento', '5-vendido', '6-pos-venda', '7-perdido'];
    this.limits = { convLLM: cfg.conv_llm_max ?? 6, dayUSD: cfg.daily_budget_usd ?? 2 };
    this.btnMap = new Map();
    for (const it of this.intents) for (const l of [null, ...this.langs]) for (const bt of (l ? it[`buttons_${l}`] : it.buttons) || []) { this.btnMap.set(this.normalize(bt), bt); this.btnMap.set(this.normalize(btnTitle(bt)), bt); }
    this.system = this.buildSystem();
  }

  applyAjustes(aj) {
    const byId = new Map(this.intents.map((i) => [i.id, i]));
    for (const it of aj.intents || []) { if (byId.has(it.id)) Object.assign(byId.get(it.id), it); else { this.intents.push(it); byId.set(it.id, it); } }
    for (const [id, exs] of Object.entries(aj.exemplos || {})) if (byId.has(id)) byId.get(id).examples = [...new Set([...(byId.get(id).examples || []), ...exs])];
    for (const [id, exs] of Object.entries(aj.remover_exemplos || {})) if (byId.has(id)) { const rm = new Set(exs.map((e) => e.toLowerCase())); byId.get(id).examples = (byId.get(id).examples || []).filter((e) => !rm.has(e.toLowerCase())); }
    for (const [id, fields] of Object.entries(aj.campos || {})) if (byId.has(id)) Object.assign(byId.get(id), fields);
    // atalhos: { se, e?, nao?, com_peca?, intent, marca? } avaliados antes do catálogo
    this.atalhos = (aj.atalhos || []).map((a) => { try { return { ...a, rx: new RegExp(a.se), rx2: a.e ? new RegExp(a.e) : null, rxNo: a.nao ? new RegExp(a.nao) : null }; } catch (e) { console.error('[ajustes] atalho inválido', a.se, e.message); return null; } }).filter(Boolean);
  }

  atalho(norm, st, hasPiece) {
    for (const a of this.atalhos || []) {
      if (!a.rx.test(norm) || (a.rx2 && !a.rx2.test(norm)) || (a.rxNo && a.rxNo.test(norm)) || (a.com_peca && !hasPiece)) continue;
      const it = this.byId.get(a.intent);
      if (!it) continue;
      if (a.marca) st[a.marca] = Date.now();
      // guarda as peças citadas ("o boss bottled é original?") para a próxima pergunta
      if (this.catalog) { const e = this.catalog.entities(norm); const f = this.catalog.hasEntities(e) || /\b[a-z]{5,}\b/.test(norm) ? this.catalog.search(norm, e, 3) : []; if (f.length) { st.products = f.map((x) => x.id); st.focus = f.length === 1 ? f[0].id : st.focus; } }
      return { ...this.intentPlan(it, st, { id: it.id, score: 1 }), intent: it.id + '*' };
    }
    return null;
  }

  async init() { if (this.catalog) { await this.catalog.load(); this.catalog.startAutoRefresh(); } }

  wantsPhoto(norm) { return RX.foto.test(norm) && !RX.pixLink.test(norm); }

  // ---------- utilidades de texto ----------
  fill(t, st = {}, extra = {}) {
    const fx = st.focus && this.catalog?.get(st.focus);
    const f = { ...(this.b.fatos || {}), ...(this.b.links || {}), nome: st.nome ? st.nome.split(' ')[0] : '', agora: new Date().toISOString(), sobre_peca: fx ? ` sobre ${fx.nome}` : '', saudacao: st.saud || saudacao(this.b.fuso), desconto_frase: this.descontoFrase(), ...extra };
    return String(t).replace(/\{\{\s*([\w.]+)\s*\}\}/g, (_, k) => (f[k] ?? '')).replace(/\s+,/g, ',').replace(/ {2,}/g, ' ').replace(/^,\s*/, '').trim();
  }

  // "com cerca de 30% de desconto sobre o preço das lojas da marca": o % mais comum no catálogo, sempre o real
  descontoFrase() {
    const it = this.catalog?.items || [];
    const key = this.catalog?.loadedAt || 0;
    if (this._desc && this._desc.key === key) return this._desc.txt;
    const cnt = {};
    for (const x of it) if (x.preco_de && x.preco_de > x.preco) { const o = Math.round((1 - x.preco / x.preco_de) * 100); if (o >= 5) cnt[o] = (cnt[o] || 0) + 1; }
    const top = Object.entries(cnt).sort((a, b) => b[1] - a[1])[0];
    const txt = top && this.b.preco_percentual ? (this.b.textos?.desconto_com_pct || 'com cerca de {pct}% de desconto sobre o preço das lojas da marca').replace('{pct}', top[0]) : (this.b.textos?.desconto_sem_pct || 'mais barato que nas lojas da marca');
    this._desc = { key, txt };
    return txt;
  }

  pick(intent, st, extra = {}) {
    const arr = V(intent, 'answer', st) || intent.answer || [];
    if (!arr.length) return '';
    st.used ||= {};
    const n = st.used[intent.id] || 0;
    st.used[intent.id] = n + 1;
    return this.fill(arr[(hash(st.key + intent.id) + n) % arr.length], st, { ...(st.slots || {}), ...extra });
  }

  msg(key, st, extra) {
    const lang = st.lang || this.lang0;
    const t = this.b[`mensagens_${lang}`]?.[key] ?? (lang !== this.lang0 ? (DEFAULT_MSG_LANG[lang] || {})[key] : undefined) ?? this.b.mensagens?.[key] ?? (DEFAULT_MSG_LANG[lang] || {})[key] ?? (lang === 'pt' || this.lang0 === 'pt' ? DEFAULT_MSG[key] : DEFAULT_MSG_LANG.en[key]) ?? '';
    return this.fill(t, st, extra);
  }
  btns(intent, st) { return V(intent, 'buttons', st) || intent.buttons || []; }

  // ---------- entrada principal ----------
  // ctx: { key, conv, text, attachments:[{type}], nome, canal }
  async turn(ctx) {
    const st = this.store.get(ctx.key, this.id);
    // conversa que voltou ao bot depois de horas (equipe resolveu e o cliente escreveu de novo): novo ciclo
    if (st.ts && Date.now() - st.ts > 6 * 36e5) { st.handoff = false; st.llm = 0; st.focus = null; st.products = []; }
    st.key = ctx.key; st.conv = ctx.conv; st.ts = Date.now();
    if (ctx.nome && !st.nome) st.nome = ctx.nome;
    if (ctx.canal) st.canal = ctx.canal;
    if (ctx.sub) st.sub = ctx.sub;
    // intenções marcadas para outra sub-marca não valem nesta caixa
    this.matcher.allow = st.sub ? (it) => !it.brands || it.brands.includes('*') || it.brands.includes(st.sub) || it.brands.includes(this.id) : null;
    // veio de anúncio (Click-to-WhatsApp/Instagram): lead mais quente e, se o anúncio cita a peça, já sabemos qual é
    if (ctx.referral && !st.ref) {
      st.ref = ctx.referral; st.origem = 'anuncio'; st.score += 15;
      const q = this.normalize(`${ctx.referral.titulo} ${ctx.referral.texto}`);
      const found = q && this.catalog ? this.catalog.search(q, this.catalog.entities(q), 3) : [];
      if (found.length) { st.refItems = found.map((x) => x.id); }
    }
    st.msgs++;
    const first = st.msgs === 1;
    if (first) this.store.bump(this.id, 'conversas');
    const raw = String(ctx.text || '').trim();
    this.hist(st, 'C', raw || `[${(ctx.attachments || []).map((a) => a.type).join(',')}]`);

    // anexos sem texto
    if (!raw && ctx.attachments?.length) {
      const t = ctx.attachments[0].type;
      if (t === 'image') st.lastImg = Date.now();
      const ev = this.flowsR.events[t];
      if (ev && /^ignor/.test(ev)) return this.reply(st, { text: '', tier: 'regra', intent: 'ignorado_' + t });
      if (st.flow && (this.flowsR.byId.get(st.flow.id)?.steps[st.flow.i]?.expect === 'media')) {
        const r = this.flowsR.handle(st, { norm: '', raw: '', attachments: ctx.attachments, lang: st.lang, fill: this.fill.bind(this) });
        if (r?.plan) return this.reply(st, this.withFlowExtras(r.plan, r, st));
      }
      const it = this.byId.get((ev && this.byId.has(ev) && ev) || (t === 'audio' ? 'audio_recebido' : 'imagem_recebida'));
      const text = it ? this.pick(it, st) : this.msg(t === 'audio' ? 'audio' : 'imagem', st);
      return this.reply(st, { text, buttons: it ? this.btns(it, st) : [], tier: 'regra', intent: it?.id || 'anexo', handoff: t !== 'audio' && it?.handoff });
    }

    let norm = this.normalize(raw);
    if (this.langs.length > 1) { const dl = detectLang(raw.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, ''), this.langs, this.lang0); if (dl) st.lang = dl; }
    // consentimento para UM lembrete dentro da janela de 24 h (sem isso, o bot nunca escreve primeiro)
    if (/\b(stop|parar|pare|nao quero mais|nao me mande|descadastr|unsubscribe|no more)\b/.test(norm)) (st.flags ||= {}).opt_in_followup = false;
    else if (/\b(me (avisa|avise|lembra|lembre)|pode me lembrar|remind me|avisame|recuerdame)\b/.test(norm)) (st.flags ||= {}).opt_in_followup = true;
    st.lang ||= this.lang0;
    let greet = false;
    { const g0 = (norm || '').match(/^(bom dia|boa tarde|boa noite)\b/); if (g0) st.saud = g0[1][0].toUpperCase() + g0[1].slice(1); }
    const g = norm.match(GREET);
    if (g && norm.length > g[0].length + 2) { greet = true; norm = norm.slice(g[0].length).trim(); }

    let plan = null;
    // primeira mensagem genérica vinda de anúncio com peça identificada: mostra a peça direto
    if (first && st.refItems?.length) {
      const c = this.matcher.classify(norm, { normalized: true });
      if (!norm || !c?.confident || /saudac|interess|informac|generic|duvida/.test(c.id)) plan = this.listPlan(st.refItems.map((id) => this.catalog.get(id)).filter(Boolean), st, null, norm);
    }
    plan ||= await this.decide(norm, st, { first, greet, raw });
    if (greet && first && plan.text && plan.tier !== 'llm' && !/^saudac/.test(plan.intent || '') && !/^(ol[aá]|oi|bom dia|boa|hi|hello|hola|tudo)/i.test(plan.text)) plan.text = this.msg('saudacao_curta', st) + ' ' + plan.text;
    return this.reply(st, plan);
  }

  async decide(norm, st, { first, raw }) {
    // -1) mensagens prontas do site: pedido do checkout e "tenho interesse em" com link da peça (custo zero)
    const site = this.siteEntry(raw, st);
    if (site) return site;

    // -0.5) fluxo guiado em andamento
    if (st.flow) {
      const r = this.flowsR.handle(st, { norm, raw, attachments: [], lang: st.lang, fill: this.fill.bind(this) });
      if (r?.plan) return this.withFlowExtras(r.plan, r, st);
      if (r) {
        st.score += r.score || 0;
        if (r.action === 'interrupt') { const p = await this.route(norm, st, { first, raw }); return { ...p, text: [p.text, r.repeat.text].filter(Boolean).join('\n\n'), buttons: r.repeat.buttons?.length ? r.repeat.buttons : p.buttons }; }
        if (r.action === 'handoff') return { text: this.msg('transbordo', st), tier: 'fluxo', intent: 'fluxo_transbordo', handoff: 'fluxo', notify: r.notify };
        if (r.action === 'llm') return this.llmPlan(norm, raw, st, this.catalog?.entities(norm) || null, null, this.id + ':' + norm);
        if (r.action === 'intent' && this.byId.get(r.target)) return { ...this.intentPlan(this.byId.get(r.target), st, null), notify: r.notify };
        if (r.notify) st.pendingNotify = r.notify;
      }
    }
    let plan = await this.route(norm, st, { first, raw });
    // cliente em outro idioma e sem resposta pronta nesse idioma: a IA responde (no idioma dele) com as mesmas peças
    if (this.langs.length > 1 && st.lang && st.lang !== this.lang0 && ['regra', 'catalogo', 'contexto', 'fluxo'].includes(plan.tier) && !plan.localized) {
      if (plan.handoff) plan.text = this.msg('transbordo', st);
      else { const photos = plan.photos; plan = await this.llmPlan(norm, raw, st, this.catalog?.entities(norm) || null, null, `${this.id}:${st.lang}:${norm}`); if (photos?.length && !plan.photos?.length) plan.photos = photos; }
    }
    // pediu foto junto com a busca: já manda (até 3), sem esperar o "manda"
    if (plan.tier === 'catalogo' && this.wantsPhoto(norm) && !plan.photos?.length && (st.focus || st.products?.length)) {
      plan.photos = st.focus ? [st.focus] : st.products.slice(0, 3);
      plan.text = plan.text.replace(/\n[^\n]*(fotos\?|Posso mandar as fotos\.)\s*$/i, '');
      st.lastOffer = null;
    }
    return plan;
  }

  withFlowExtras(plan, r, st) {
    st.score += r.score || 0;
    return { ...plan, notify: r.notify || plan.notify };
  }

  async route(norm, st, { first, raw }) {
    const p = await this.route0(norm, st, { first, raw });
    // intenção que pede IA quando há peça na conversa (ex.: notas olfativas de um perfume citado)
    if (p?.llm) return this.llmPlan(norm, raw, st, this.catalog?.entities(norm) || null, null, this.id + ':' + norm + ':' + (st.focus || (st.products || []).join(',')));
    return p;
  }

  async route0(norm, st, { first, raw }) {
    // só pontuação/emoji ("?", "👀"): resposta pronta, sem IA
    if (!norm) { const v = this.byId.get('pergunta_vaga') || this.byId.get('saudacao'); if (v) return this.intentPlan(v, st, null); }
    // "tem essa?" logo depois de mandar uma foto: a equipe olha a imagem (o bot não gasta IA com visão)
    const eImg = st.lastImg && this.catalog ? this.catalog.entities(norm) : null;
    if (st.lastImg && Date.now() - st.lastImg < 15 * 60e3 && RX.essa.test(norm) && !(eImg && (eImg.cores.length || eImg.preco_max || eImg.marcas.length))) {
      st.lastImg = null;
      return { text: this.msg('foto_equipe', st), tier: 'regra', intent: 'foto_cliente', handoff: 'foto enviada pelo cliente', stage: '2-em-atendimento' };
    }
    // 0) botão clicado (título exato)
    const btnIntent = this.buttonAction(norm, st);
    if (btnIntent) return btnIntent;

    // 1) CEP informado -> fechamento (frete) com transbordo
    const cep = norm.match(RX.cep) || raw.match(/\b(\d{5})-?(\d{3})\b/);
    if (cep && /cep|frete|entrega|envio|\d{5}-?\d{3}/.test(norm + raw)) {
      st.cep = cep[1] + '-' + cep[2]; st.score += 30; (st.slots ||= {}).cep = st.cep;
      return { text: this.msg('cep_recebido', st, { cep: st.cep }), tier: 'regra', intent: 'cep', handoff: 'frete', stage: '4-aguardando-pagamento' };
    }

    // "a segunda da lista" sem lista na conversa: pergunta qual peça, sem chutar intenção
    if (!(st.products || []).length && /^(a |o )?(primeir[ao]|segund[ao]|terceir[ao]|ultim[ao]|da lista|essa da lista)\b/.test(norm) && norm.split(' ').length <= 5) { const v = this.byId.get('pergunta_vaga'); if (v) return this.intentPlan(v, st, null); }

    // 1b) atalhos do pacote (pós-venda, pagamento feito, negociação, fechamento, autenticidade…): vencem o catálogo
    const hasPiece = !!(st.focus || (st.products || []).length);
    const at = this.atalho(norm, st, hasPiece);
    if (at) return at;

    // 1c) "quero", "fecha pra mim", "manda o pix" com peça na conversa: fechamento com a equipe
    if (hasPiece && (RX.fechar.test(norm) || RX.pixLink.test(norm))) {
      const listedF = (st.products || []).map((id) => this.catalog?.get(id)).filter(Boolean);
      let x = this.selectFromList(norm, st);
      if (!x) { const want = this.catalog?.entities(norm).tamanho || norm.match(/\bno (\d{1,2}(?:\.5)?|pp|p|m|g|gg|xs|xl|xxl)\b/)?.[1]; if (want) { const c = listedF.filter((y) => sizeMatch(y, want)); if (c.length === 1) x = c[0]; } }
      x ||= (st.focus && this.catalog?.get(st.focus)) || (listedF.length === 1 ? listedF[0] : null);
      if (x) st.focus = x.id;
      return this.closePlan(st, x);
    }

    // 2) seleção de item da última lista ("2", "a segunda", "a preta")
    const sel = this.selectFromList(norm, st);
    if (sel) {
      st.focus = sel.id; st.score += 10;
      const wantPhoto = this.wantsPhoto(norm);
      return { text: this.productCard(sel, st), tier: 'contexto', intent: 'selecao', photos: wantPhoto ? [sel.id] : [], buttons: ['Ver fotos', 'Quero comprar', 'Mais opções'], stage: '3-proposta-enviada' };
    }

    // 3) classificação de intenção (custo zero)
    const parts = norm.split(/\s*[?!.]\s*|\s+e\s+(?=(?:aceita|qual|quanto|tem|como|voces|faz|da|entrega|parcela))/).map((s) => s.trim()).filter((s) => s.length > 2);
    const cls = this.matcher.classify(norm, { normalized: true });
    const it = cls && this.byId.get(cls.id);
    const ents = this.catalog ? this.catalog.entities(norm) : null;
    const listed0 = (st.products || []).map((id) => this.catalog?.get(id)).filter(Boolean);
    // "a mais barata" / "só isso?" sobre a lista atual (não herdar categoria nem buscar de novo)
    if (ents && listed0.length >= 2 && !ents.categorias.length && !ents.cores.length && (RX.extremo.test(norm))) { const c = this.contextAnswer(norm, st, null, listed0, cls); if (c) return c; }
    if (ents && RX.mais.test(norm) && st.lastEnts && (!ents.categorias.length || ents.categorias.every((c) => (st.lastEnts.categorias || []).includes(c)))) return this.moreOptions(st);
    // cintura em cm com cintos na conversa
    const cm = norm.match(/\b(\d{2,3})\s?cm\b/);
    if (cm && listed0.some((x) => /cinto/i.test(x.nome))) {
      const belts = listed0.filter((x) => /cinto/i.test(x.nome));
      const ok = belts.map((x) => ({ x, t: (x.tamanhos || []).map(Number).filter((n) => n >= +cm[1] + 3).slice(0, 2) })).filter((y) => y.t.length);
      if (ok.length) return { text: this.msg('cinto_cm', st, { cm: cm[1] }) + '\n' + ok.map((y) => `${this.label(y.x, belts)}: ${y.t.join(', ')}`).join('\n') + '\n' + this.msg('tamanho_confirma', st), tier: 'contexto', intent: 'ctx_cinto_cm', buttons: ['Quero comprar', 'Ver fotos'] };
    }
    // link de uma peça citada pelo nome
    if (ents && RX.link.test(norm)) {
      const f = this.catalog.search(norm, ents, 2);
      if (f.length === 1) { st.focus = f[0].id; st.products = [f[0].id]; return { text: this.msg('link_produto', st, { produto: f[0].nome, link: f[0].link }), tier: 'catalogo', intent: 'link_peca', buttons: ['Quero comprar', 'Ver fotos'], stage: '3-proposta-enviada' }; }
    }
    if (ents && !ents.categorias.length && !ents.marcas.length && (ents.preco_max || ents.preco_min || ents.cores.length || ents.tamanho || ents.ordenar) && st.lastEnts && Date.now() - (st.lastEntsTs || 0) < 30 * 60e3) {
      ents.categorias = st.lastEnts.categorias || []; ents.marcas = st.lastEnts.marcas || []; ents.genero ||= st.lastEnts.genero;
      // herda também a peça ("ternos" -> "uso 50" continua nos ternos)
      if (st.lastPeca && !this.catalog.pecaIn(norm)) norm = `${norm} ${st.lastPeca}`;
    }
    if (ents && !ents.genero && (st.genero || st.slots?.genero)) ents.genero = st.genero || st.slots.genero;
    if (ents?.genero) st.genero = ents.genero;
    const prodLike = ents && this.catalog.hasEntities(ents);
    const isCatalogIntent = it && (cls.confident || cls.score >= 0.5) && (it.needs?.includes('produto') || /catalog|bolsa|perfume|tenis|sapato|carteira|roupa|acessor|calcad|cinto|gorro|necess|terno|miu|preco_|faixa|barat|presente|novidade|dispon|foto|cor|tamanho/.test(it.id));

    // 3a) perguntas de contexto sobre a peça em foco (preço, tamanho, foto, link, mais opções)
    const focus = st.focus && this.catalog?.get(st.focus);
    const listed = (st.products || []).map((id) => this.catalog?.get(id)).filter(Boolean);
    if ((focus || listed.length) && !prodLike) {
      const c = this.contextAnswer(norm, st, focus, listed, cls);
      if (c) return c;
    }

    // 3b) várias perguntas na mesma mensagem: responde cada intenção confiante (até 2)
    if (parts.length >= 2 && !prodLike) {
      const seen = new Set(); const answers = []; let handoff = false; let btns = [];
      for (const p of parts) {
        const c = this.matcher.classify(p, { normalized: true });
        const ii = c?.confident && this.byId.get(c.id);
        if (ii && !seen.has(ii.id) && !/saudacao|despedida/.test(ii.id)) { seen.add(ii.id); answers.push(this.pick(ii, st)); handoff ||= !!ii.handoff; btns = this.btns(ii, st).length ? this.btns(ii, st) : btns; }
      }
      if (answers.length >= 2) return { text: answers.slice(0, 2).join('\n\n'), tier: 'regra', intent: [...seen].join('+'), buttons: btns, handoff: handoff && 'pergunta' };
    }

    // 3c) intenção de política/atendimento confiante (não-catálogo)
    if (cls?.confident && it && !(prodLike && isCatalogIntent)) {
      if (prodLike && !isCatalogIntent) {
        // ex.: "a bolsa preta é original?" -> responde a política e guarda as peças citadas
        const found = this.catalog.search(norm, ents, 3);
        if (found.length) { st.products = found.map((x) => x.id); if (found.length === 1) st.focus = found[0].id; }
      }
      return this.intentPlan(it, st, cls);
    }

    // 4) catálogo
    if (prodLike || isCatalogIntent) {
      const r = this.catalogAnswer(norm, st, ents, it);
      if (r && parts.length >= 2) {
        // "tem carteira? qual o preço e entrega pra campinas? aceita pix?": lista + até 2 respostas de política
        const seen = new Set(); const extra = [];
        for (const p of parts) {
          const c = this.matcher.classify(p, { normalized: true });
          const ii = c?.confident && this.byId.get(c.id);
          if (ii && !seen.has(ii.id) && !ii.needs?.includes('produto') && !/saudac|despedida|catalog|preco|faixa|dispon|foto|bolsa|perfume|tenis|sapato|carteira|roupa|acessor|calcad|cinto|gorro|necess|terno|miu/.test(ii.id)) { seen.add(ii.id); extra.push(this.pick(ii, st)); if (ii.handoff) r.handoff ||= ii.id; }
          if (extra.length >= 2) break;
        }
        if (extra.length) r.text += '\n\n' + extra.join('\n\n');
      }
      if (r) return r;
    }
    // 4b) nome de modelo sem categoria ("flora", "bauletto", "americas cup")
    if (this.catalog) {
      const found = this.catalog.search(norm, ents, 5);
      if (found.length) return this.listPlan(found, st, ents, norm);
    }

    // 5) intenção com confiança média: ainda é melhor que gastar LLM
    if (cls && it && cls.score >= 0.5 && cls.margin >= 0.03) return this.intentPlan(it, st, cls);

    // 6) cache de respostas do LLM
    const ck = this.id + ':' + norm;
    const hit = this.store.cacheGet(ck);
    if (hit) return { text: hit.text, tier: 'cache', intent: 'cache', handoff: hit.handoff ? 'llm' : false };

    // 7) LLM (com limites)
    return this.llmPlan(norm, raw, st, ents, cls, ck);
  }

  // fechamento: se o pacote tem fluxo de compra (entrega, CEP, pagamento), passa por ele; senão, transbordo direto
  closePlan(st, x) {
    st.score += 25;
    const cq = this.byId.get('comprar_quero');
    if (cq && this.flowsR.forIntent('comprar_quero') && !st.flow) {
      st.flowStarts = { ...(st.flowStarts || {}), [this.flowsR.forIntent('comprar_quero').id]: 0 };
      const p = this.intentPlan(cq, st, null);
      if (p.tier === 'fluxo') return { ...p, text: (x ? `${x.nome} · ${this.priceTxt(x)}\n` : '') + p.text };
    }
    return { text: this.msg('comprar', st, { link: x ? x.link : this.b.links?.site, produto: x ? x.nome : 'a peça' }), tier: 'regra', intent: 'fechamento', handoff: 'fechamento', stage: '4-aguardando-pagamento' };
  }

  siteEntry(raw, st) {
    const pedido = raw.match(/finalizar (?:meu )?pedido\s+([A-Z0-9-]{4,})/i);
    if (pedido) {
      st.pedido = pedido[1]; st.score += 60;
      const cep = raw.match(/CEP\s*(\d{5})-?(\d{3})/i); if (cep) st.cep = cep[1] + '-' + cep[2];
      return { text: this.msg('pedido_site', st, { pedido: st.pedido }), tier: 'regra', intent: 'pedido_site', handoff: 'pedido do site ' + st.pedido, stage: '4-aguardando-pagamento' };
    }
    if (!this.catalog || !/privoutlets\.com\.br\/(produto\/|#p\/)/i.test(raw)) return null;
    const x = this.catalog.byLink(raw);
    if (!x) return null;
    st.focus = x.id; st.products = [x.id]; st.score += 15; st.lastOffer = 'fotos';
    return { text: this.msg('interesse_site', st) + '\n' + this.productCard(x, st), tier: 'regra', intent: 'interesse_site', photos: [x.id], buttons: ['Quero comprar', 'Outras opções', 'Falar com a equipe'], stage: '3-proposta-enviada' };
  }

  buttonAction(norm, st) {
    const bt = this.btnMap.get(norm) || (st.btns || []).find((b) => this.normalize(b) === norm || this.normalize(btnTitle(b)) === norm);
    const n = /^\d$/.test(norm) && !(st.products || []).length && st.btns?.[+norm - 1];
    const title = bt || n || yesNoButton(norm, st.btns, this.normalize);
    if (!title) return null;
    const t = this.normalize(title);
    const focus = st.focus && this.catalog?.get(st.focus);
    const listed = (st.products || []).map((id) => this.catalog?.get(id)).filter(Boolean);
    if (/^ver fotos?$|^fotos$/.test(t)) {
      const ids = focus ? [focus.id] : listed.slice(0, 3).map((x) => x.id);
      if (ids.length) return { text: ids.length > 1 ? this.msg('fotos_seguem', st) : '', tier: 'contexto', intent: 'btn_fotos', photos: ids, buttons: ['Quero comprar', 'Mais opções', 'Falar com a equipe'] };
    }
    if (/^quero comprar|^comprar$/.test(t)) {
      const x = focus || (listed.length === 1 ? listed[0] : null);
      if (x) st.focus = x.id;
      return this.closePlan(st, x);
    }
    if (/^mais opcoes$|^ver mais$|^outras opcoes$/.test(t)) return st.lastEnts ? this.moreOptions(st) : this.similar(st);
    if (/^falar com a equipe$|^atendente$|^humano$/.test(t)) return { text: this.msg('transbordo', st), tier: 'regra', intent: 'btn_humano', handoff: 'pedido do cliente' };
    // botão que corresponde a uma intenção/categoria ("Ver bolsas", "Ver perfumes")
    const ents = this.catalog?.entities(t);
    if (ents && !ents.genero && (st.genero || st.slots?.genero)) ents.genero = st.genero || st.slots.genero;
    if (ents && this.catalog.hasEntities(ents)) return this.catalogAnswer(t, st, ents, null);
    const c = this.matcher.classify(t, { normalized: true });
    if (c?.confident) return this.intentPlan(this.byId.get(c.id), st, c);
    return null;
  }

  intentPlan(it, st, cls) {
    // mesma pergunta, resposta conforme a categoria da conversa (ex.: tabela de medidas de roupa x calçado)
    if (it.por_categoria && st.lastEnts?.categorias?.length && Date.now() - (st.lastEntsTs || 0) < 30 * 60e3) {
      const alvo = Object.entries(it.por_categoria).find(([k]) => st.lastEnts.categorias.includes(k) || st.lastPeca === k)?.[1];
      if (alvo && this.byId.get(alvo) && alvo !== it.id) return this.intentPlan(this.byId.get(alvo), st, cls);
    }
    if (it.set) this.flowsR.setVars(st, it.set, this.fill.bind(this));
    const focus0 = st.focus && this.catalog?.get(st.focus);
    if (it.id === 'lista_espera' && focus0) {
      const tam = st.waitSize ? ` no ${st.waitSize}` : '';
      (st.flags ||= {}).lista_espera = focus0.id;
      return { text: this.msg('lista_espera_ok', st, { produto: focus0.nome + tam }), tier: 'regra', intent: 'lista_espera', labels: ['lista-de-espera'], notify: `Lista de espera: ${focus0.nome}${tam} (${focus0.id}) · ${st.nome || 'cliente'}`, stage: it.label || null };
    }
    const flow = (it.flow && this.flowsR.byId.get(it.flow)) || this.flowsR.forIntent(it.id);
    st.flowStarts ||= {};
    if (flow && !st.flow && Date.now() - (st.flowStarts[flow.id] || 0) > 10 * 60e3) {
      const p = this.flowsR.start(flow, st, st.lang, this.fill.bind(this));
      if (p) {
        st.flowStarts[flow.id] = Date.now();
        const pre = it.antes_do_fluxo ? this.fill(it.antes_do_fluxo, st) + ' ' : '';
        const body = pre ? String(p.text || '').replace(/^(ol[aá]|oi)[!,.]?\s*/i, '').replace(/^./, (c) => c.toUpperCase()) : p.text || this.pick(it, st);
        return { ...p, text: pre + body, intent: `${it.id}>${p.intent}`, conf: cls?.score, labels: [...(p.labels || []), ...(it.labels_extra || [])], handoff: p.handoff };
      }
    }
    // intenções que pedem produto e o cliente já tem uma peça em foco
    const focus = st.focus && this.catalog?.get(st.focus);
    // com a peça identificada, responde com o cartão dela (ex.: "é EDT ou EDP?", "qual o material?")
    if (it.cartao_com_peca && focus) return { text: this.productCard(focus, st), tier: 'contexto', intent: it.id + '+peca', buttons: ['Ver fotos', 'Quero comprar', 'Mais opções'] };
    if (it.ia_com_peca && (focus || (st.products || []).length)) return { llm: true, intent: it.id };
    const text = this.pick(it, st, focus ? { produto: focus.nome, preco: fmtBRL(focus.preco), link: focus.link } : {});
    return { text, tier: 'regra', intent: it.id, conf: cls?.score, buttons: this.btns(it, st), labels: it.labels_extra || [], handoff: it.handoff ? it.id : false, stage: it.label || null, localized: !!(st.lang && it[`answer_${st.lang}`]) };
  }

  contextAnswer(norm, st, focus, listed, cls) {
    const target = focus ? [focus] : listed.slice(0, 3);
    // "qual a diferença?" entre as peças listadas: um bloco por peça, sem IA
    if (RX.diferenca.test(norm) && !focus && listed.length >= 2) {
      const L3 = listed.slice(0, 3);
      return { text: L3.map((x) => `${this.label(x, L3)}: ${[x.modelo ? 'modelo ' + x.modelo : '', x.material, x.tipo === 'perfume' ? `${x.ml} ml ${x.conc}` : '', (x.tamanhos || []).length ? 'tam. ' + x.tamanhos.join(', ') : '', fmtBRL(x.preco)].filter(Boolean).join(' · ')}`).join('\n') + '\n' + this.msg('diferenca_fim', st), tier: 'contexto', intent: 'ctx_diferenca', buttons: ['Ver fotos', 'Quero comprar', 'Falar com a equipe'] };
    }
    // "a mais barata", "a maior" entre as listadas
    const ext = norm.match(RX.extremo);
    if (ext && listed.length >= 2) {
      const w = ext[0];
      if (/menor|maior/.test(w)) { const d = this.byId.get('dimensoes_peca'); if (d) return this.intentPlan(d, st, null); }
      const sorted = [...listed].sort((a, b) => (/barat/.test(w) ? a.preco - b.preco : b.preco - a.preco));
      if (sorted[0].preco === sorted[1].preco) return { text: this.msg('mesmo_preco', st, { preco: fmtBRL(sorted[0].preco) }) + '\n' + sorted.filter((x) => x.preco === sorted[0].preco).map((x) => `- ${this.label(x, listed)}`).join('\n'), tier: 'contexto', intent: 'ctx_extremo', buttons: ['Ver fotos', 'Quero comprar'] };
      st.focus = sorted[0].id;
      return { text: this.productCard(sorted[0], st), tier: 'contexto', intent: 'ctx_extremo', buttons: ['Ver fotos', 'Quero comprar', 'Mais opções'], stage: '3-proposta-enviada' };
    }
    if (this.wantsPhoto(norm) && !/\b(original|falsific|autentic|nota)\b/.test(norm)) {
      return { text: target.length > 1 ? this.msg('fotos_seguem', st) : '', tier: 'contexto', intent: 'ctx_fotos', photos: target.map((x) => x.id), buttons: ['Quero comprar', 'Mais opções', 'Falar com a equipe'] };
    }
    if (RX.mais.test(norm)) return this.moreOptions(st);
    if (RX.outraCor.test(norm) && (focus || target.length === 1)) {
      const x = focus || target[0];
      const want = this.catalog.entities(norm).cores;
      let sib = this.catalog.siblings(x);
      sib = want.length ? sib.filter((y) => want.some((c) => (y.cor || '').split(/\s*\+\s*/).includes(c))) : sib.filter((y) => y.cor !== x.cor);
      if (sib.length) return this.listPlan(sib, st, null, norm);
      return { text: this.msg('sem_outra_cor', st, { produto: x.nome }), tier: 'contexto', intent: 'ctx_outra_cor', buttons: ['Outras opções', 'Quero comprar', 'Falar com a equipe'] };
    }
    if (RX.qualquer.test(norm) && norm.split(' ').length <= 5) return { text: target.length > 1 ? this.msg('fotos_seguem', st) : '', tier: 'contexto', intent: 'ctx_qualquer', photos: target.map((x) => x.id), buttons: ['Quero comprar', 'Mais opções', 'Falar com a equipe'] };
    if (RX.preco.test(norm) && !/\b(frete|entrega|envio|parcel|desconto)\b/.test(norm)) {
      const lines = target.map((x) => `${this.label(x, target)}: ${this.priceTxt(x)}`);
      const pg = /\b(pix|cartao|a vista|avista)\b/.test(norm) ? '\n' + this.msg('pagamento_obs', st) : '';
      return { text: lines.join('\n') + pg + '\n' + this.msg('pos_preco', st), tier: 'contexto', intent: 'ctx_preco', buttons: ['Quero comprar', 'Ver fotos', 'Mais opções'], stage: '3-proposta-enviada', score: 10 };
    }
    const num = norm.match(/^(?:e\s+)?(?:tem\s+)?(?:o |no |na |em |uso |visto |calco |calca |meu numero e |numero |tamanho )?(\d{1,3}(?:\.5)?|pp|p|m|g|gg|xg|xgg|eg|xs|s|l|xl|xxl)(?: br)?\??$/);
    const explicit = num || this.catalog?.entities(norm).tamanho || /\b(\d{2,3}(?:\.5)?|pp|gg|xg|xs|xl|xxl)\b/.test(norm);
    const sizeAsk = (RX.tamanho.test(norm) || num) && !(!explicit && cls?.confident && /numera|medida|tabela/.test(cls.id));
    if (sizeAsk && !focus && listed.length > 1) {
      // pergunta de tamanho sobre a lista inteira: diz em quais peças tem
      const want = num ? num[1].toUpperCase() : (norm.match(/\b(\d{2}(?:\.5)?|pp|gg|xs|xl|xxl|p|m|g)\b/)?.[1] || '').toUpperCase();
      const withSizes = listed.filter((x) => x.tipo !== 'perfume' && (x.tamanhos || []).length);
      if (want && withSizes.length) {
        const have = withSizes.filter((x) => sizeMatch(x, want));
        const conv = have.length ? sizeMatch(have[0], want).conv : null;
        if (have.length === 1) { st.focus = have[0].id; return { text: this.msg('tamanho_tem', st, { tam: conv ? `${want} (${conv})` : want, produto: have[0].nome }) + (sizeMatch(have[0], want).uk ? ' ' + this.msg('tamanho_confirma', st) : ''), tier: 'contexto', intent: 'ctx_tamanho', buttons: ['Quero comprar', 'Ver fotos'] }; }
        if (have.length > 1) { st.products = have.map((x) => x.id); return { text: this.msg('tamanho_lista', st, { tam: conv ? `${want} (${conv})` : want }) + '\n' + have.map((x, i) => `${i + 1}. ${this.label(x, have)} — ${this.priceTxt(x)}`).join('\n'), tier: 'contexto', intent: 'ctx_tamanho', buttons: ['Ver fotos', 'Quero comprar'] }; }
        return { text: this.msg('tamanho_nenhum', st, { tam: want }) + '\n' + withSizes.map((x) => `${this.label(x, withSizes)}: ${x.tamanhos.join(', ')}`).join('\n'), tier: 'contexto', intent: 'ctx_tamanho', buttons: ['Mais opções', 'Lista de espera', 'Falar com a equipe'] };
      }
    }
    if (sizeAsk) {
      const x = focus || listed[0];
      if (x && x.tipo !== 'perfume') {
        const sizes = (x.tamanhos || []).map(String);
        const want = num ? num[1].toUpperCase() : (norm.match(/\b(\d{2}(?:\.5)?|pp|gg|xs|xl|xxl)\b/)?.[1] || '').toUpperCase();
        if (!sizes.length) return { text: this.msg('tamanho_unico', st, { produto: x.nome }), tier: 'contexto', intent: 'ctx_tamanho' };
        if (want) {
          const sm = sizeMatch(x, want);
          if (sm) return { text: this.msg('tamanho_tem', st, { tam: sm.conv ? `${want} (${sm.conv})` : want, produto: x.nome }) + (sm.uk ? ' ' + this.msg('tamanho_confirma', st) : ''), tier: 'contexto', intent: 'ctx_tamanho', buttons: ['Quero comprar', 'Ver fotos'] };
          st.waitSize = want;
          return { text: this.msg('tamanho_nao_tem', st, { tam: want, tams: sizes.join(', ') }), tier: 'contexto', intent: 'ctx_tamanho', buttons: ['Lista de espera', 'Outras opções', 'Falar com a equipe'] };
        }
        return { text: this.msg('tamanhos_disp', st, { produto: x.nome, tams: sizes.join(', ') }), tier: 'contexto', intent: 'ctx_tamanho', buttons: ['Quero comprar', 'Ver fotos'] };
      }
    }
    if (RX.link.test(norm) && !cls?.confident) {
      const x = focus || listed[0];
      return { text: this.msg('link_produto', st, { produto: x.nome, link: x.link }), tier: 'contexto', intent: 'ctx_link', buttons: ['Quero comprar', 'Falar com a equipe'], stage: '3-proposta-enviada' };
    }
    if (RX.sim.test(norm) && st.lastOffer === 'fotos') return { text: '', tier: 'contexto', intent: 'ctx_sim_fotos', photos: target.map((x) => x.id), buttons: ['Quero comprar', 'Mais opções'] };
    return null;
  }

  label(x, list) {
    const others = (list || []).filter((y) => y !== x && y.id !== x.id && y.nome === x.nome);
    if (!others.length) return x.nome;
    const mat = x.material && others.every((y) => y.material !== x.material) ? x.material.toLowerCase() : null;
    return `${x.nome} (${mat ? 'em ' + mat : 'modelo ' + (x.modelo || x.cor || x.id)})`;
  }

  priceTxt(x) {
    if (!(x.preco_de && x.preco_de > x.preco)) return fmtBRL(x.preco);
    const off = Math.round((1 - x.preco / x.preco_de) * 100);
    return `de ${fmtBRL(x.preco_de)} por ${fmtBRL(x.preco)}${this.b.preco_percentual && off > 0 ? ` (-${off}%)` : ''}`;
  }

  productCard(x, st) {
    const extra = x.tipo === 'perfume' ? `${x.ml} ml, ${x.conc === 'EDP' ? 'Eau de Parfum' : 'Eau de Toilette'}` : [x.material, (x.tamanhos || []).length ? 'tamanhos ' + x.tamanhos.join(', ') : null].filter(Boolean).join(' · ');
    return `${x.titulo || x.nome}\n${this.priceTxt(x)}${extra ? '\n' + extra : ''}\n${x.link}`;
  }

  catalogAnswer(norm, st, ents, it) {
    if (!this.catalog) return null;
    const found = this.catalog.search(norm, ents, 5);
    if (!found.length) {
      const what = [ents.categorias[0], ents.cor_txt || ''].join(' ').trim() || 'essa peça';
      st.lastEnts = { ...ents, cores: [], tamanho: null }; st.lastEntsTs = Date.now(); st.lastQuery = norm;
      // só o tamanho não existe: diz quais tamanhos há
      if (ents.tamanho) {
        const noSize = this.catalog.search(norm, { ...ents, tamanho: null }, 5);
        if (noSize.length) {
          st.products = noSize.slice(0, 3).map((x) => x.id); st.focus = noSize.length === 1 ? noSize[0].id : null; st.waitSize = ents.tamanho;
          return { text: this.msg('tamanho_nenhum', st, { tam: ents.tamanho }) + '\n' + noSize.slice(0, 3).map((x) => `${this.label(x, noSize)}: ${(x.tamanhos || []).join(', ') || 'tamanho único'}`).join('\n'), tier: 'catalogo', intent: 'catalogo_sem_tamanho', buttons: ['Lista de espera', 'Ver fotos', 'Falar com a equipe'], stage: '2-em-atendimento' };
        }
      }
      // relaxa a cor/preço para sugerir alternativa
      const alt = this.catalog.search(norm, { ...ents, cores: [], preco_max: null, preco_min: null, tamanho: null }, 3);
      if (alt.length && alt.every((x) => (st.products || []).includes(x.id))) {
        const cores = [...new Set(this.catalog.search(norm, { ...ents, cores: [], preco_max: null, preco_min: null, tamanho: null }, 60).map((x) => x.cor_pt).filter(Boolean))].slice(0, 8);
        return { text: this.msg('sem_cor', st, { item: what, cores: cores.join(', ') }), tier: 'catalogo', intent: 'catalogo_cores', buttons: ['Lista de espera', 'Ver fotos', 'Falar com a equipe'] };
      }
      if (alt.length) {
        st.products = alt.map((x) => x.id); st.focus = alt.length === 1 ? alt[0].id : null; st.page = 0;
        return { text: this.msg('sem_resultado_alt', st, { item: what }) + '\n' + alt.map((x, i) => `${i + 1}. ${this.label(x, alt)} — ${this.priceTxt(x)}`).join('\n'), tier: 'catalogo', intent: 'catalogo_alt', buttons: ['Ver fotos', 'Lista de espera', 'Falar com a equipe'], stage: '2-em-atendimento' };
      }
      return { text: this.msg('sem_resultado', st, { item: what }), tier: 'catalogo', intent: 'catalogo_vazio', buttons: ['Lista de espera', 'Ver tudo'], extraLabels: [] };
    }
    return this.listPlan(found, st, ents, norm);
  }

  listPlan(found, st, ents, norm) {
    st.products = found.map((x) => x.id); st.page = 0; st.lastQuery = norm; st.lastEnts = ents; st.lastEntsTs = Date.now();
    if (ents?.categorias?.length) st.lastPeca = this.catalog.pecaIn(norm);
    st.score += 5;
    if (found.length === 1) {
      st.focus = found[0].id; st.lastOffer = 'fotos';
      return { text: this.productCard(found[0], st) + '\n' + this.msg('quer_fotos', st), tier: 'catalogo', intent: 'catalogo_1', buttons: ['Ver fotos', 'Quero comprar', 'Mais opções'], stage: '3-proposta-enviada' };
    }
    st.focus = null; st.lastOffer = 'fotos';
    const total = ents ? this.catalog.count(ents, norm) : found.length;
    const seenN = new Set(); const first = [], rest = [];
    for (const x of found) (seenN.has(x.nome) ? rest : first).push(x), seenN.add(x.nome);
    const shown = [...first, ...rest].slice(0, 3);
    st.products = shown.map((x) => x.id);
    const lines = shown.map((x, i) => `${i + 1}. ${this.label(x, shown)} — ${this.priceTxt(x)}`);
    const conv = ents?.tamanho && sizeMatch(shown[0], ents.tamanho)?.conv;
    const cat = ents?.categorias?.[0];
    const more = total > shown.length ? '\n' + this.msg('ver_todas', st, { total, link: (this.b.links_categoria || {})[cat] || this.b.links?.site }) : '';
    return { text: (conv ? this.msg('tamanho_lista', st, { tam: `${ents.tamanho} (${conv})` }) : this.msg('lista_intro', st)) + '\n' + lines.join('\n') + more + '\n' + this.msg('lista_pergunta', st), tier: 'catalogo', intent: 'catalogo_lista', buttons: ['Ver fotos', 'Mais opções', 'Falar com a equipe'], stage: '2-em-atendimento' };
  }

  // peças parecidas com a que está em foco (mesma categoria/gênero), quando não houve busca antes
  similar(st) {
    const x = st.focus && this.catalog?.get(st.focus);
    if (!x) return this.moreOptions(st);
    const ents = { ...this.catalog.entities(''), categorias: [x.categoria].filter(Boolean), genero: x.genero !== 'unissex' ? x.genero : null };
    const found = this.catalog.search(this.normalize(x.categoria || ''), ents, 8).filter((y) => y.id !== x.id);
    if (!found.length) return this.moreOptions(st);
    return this.listPlan(found, st, ents, this.normalize(x.categoria || ''));
  }

  moreOptions(st) {
    if (!this.catalog || !st.lastEnts) return { text: this.msg('ver_site', st), tier: 'contexto', intent: 'mais_sem_contexto', buttons: ['Ver bolsas', 'Ver perfumes'] };
    st.page = (st.page || 0) + 1;
    const all = this.catalog.search(st.lastQuery || '', st.lastEnts, 60);
    const page = all.slice(st.page * 3, st.page * 3 + 3);
    if (!page.length) return { text: this.msg('fim_lista', st, { link: (this.b.links_categoria || {})[st.lastEnts.categorias?.[0]] || this.b.links?.site }), tier: 'contexto', intent: 'fim_lista', buttons: ['Falar com a equipe'] };
    st.products = page.map((x) => x.id); st.focus = null;
    return { text: page.map((x, i) => `${i + 1}. ${this.label(x, page)} — ${this.priceTxt(x)}`).join('\n') + '\n' + this.msg('lista_pergunta', st), tier: 'contexto', intent: 'mais_opcoes', buttons: ['Ver fotos', 'Mais opções', 'Falar com a equipe'] };
  }

  selectFromList(norm, st) {
    const listed = (st.products || []).map((id) => this.catalog?.get(id)).filter(Boolean);
    if (listed.length < 2) return null;
    const ml = norm.match(/\b(\d{2,3})\s?ml\b/);
    if (ml && norm.split(' ').length <= 9) { const h = listed.filter((x) => +x.ml === +ml[1]); if (h.length === 1) return h[0]; }
    // "última oferta 3300" não é "a última da lista"
    if (/\b(ultim[ao]|primeir[ao]) (oferta|proposta|vez|chance|preco|valor)\b/.test(norm) || /\b\d{3,}\b/.test(norm.replace(/\b\d{2,3}\s?ml\b/, ''))) return null;
    let m = norm.match(/^(?:a |o |quero a |quero o |gostei da |gostei do |essa |esse |me fala da |me fala do |ver a |ver o |numero |opcao )?(\d)(?:a|o)?\b/);
    if (m && +m[1] >= 1 && +m[1] <= listed.length && norm.split(' ').length <= 6) return listed[+m[1] - 1];
    for (const [w, n] of Object.entries(ORDINAIS)) if (new RegExp(`\\b${w}\\b`).test(norm) && norm.split(' ').length <= 6) return n === -1 ? listed[listed.length - 1] : listed[n - 1];
    // pela cor ou palavra exclusiva de um item da lista
    const words = norm.split(' ').filter((w) => w.length > 3);
    const hits = listed.filter((x) => words.some((w) => (x.cor_pt || '').includes(w) || (x.cor || '').toLowerCase() === w));
    if (hits.length === 1 && norm.split(' ').length <= 5) return hits[0];
    return null;
  }

  // ---------- LLM ----------
  buildSystem() {
    const b = this.b;
    return [
      `Você é o atendente virtual da ${b.nome || this.id} no ${b.canal || 'WhatsApp'}. ${b.persona || ''}`,
      `Regras: ${(b.regras || []).join(' ')}`,
      `Responda curto (máximo 3 frases, sem listas longas), ${this.langs.length > 1 ? `no idioma da mensagem do cliente (${this.langs.join(', ')})` : `em ${b.idioma || 'português do Brasil'}, tratando por "você"`}. Nunca invente fatos, preços, estoque, prazos ou políticas: use só o CONTEXTO e o CONHECIMENTO. Se não souber ou envolver desconto, troca, reclamação, pagamento ou frete, diga que a equipe confirma e marque h=1. Fora do assunto: desvie com elegância para as peças, sem opinar e sem inventar (clima, notícias, pessoas).`,
      (b.proibido || []).length ? `Nunca: ${b.proibido.join('; ')}.` : '',
      this.kb ? `CONHECIMENTO:\n${this.kb.trim()}` : '',
      'Saída: só JSON {"r":"resposta","h":0 ou 1,"f":["ids de produtos para mandar foto"],"i":"intenção curta"}.',
    ].filter(Boolean).join('\n');
  }

  async llmPlan(norm, raw, st, ents, cls, ck) {
    if (st.llm >= this.limits.convLLM || this.store.spentToday() >= this.limits.dayUSD) {
      return { text: this.msg('limite', st), tier: 'limite', intent: 'limite_llm', handoff: 'limite de IA' };
    }
    const found = this.catalog ? this.catalog.search(norm, ents || this.catalog.entities(norm), 5) : [];
    const focus = st.focus && this.catalog?.get(st.focus);
    const listed = (st.products || []).map((id) => this.catalog?.get(id)).filter(Boolean);
    const ctxItems = [...new Map([...(focus ? [focus] : []), ...listed, ...found].map((x) => [x.id, x])).values()].slice(0, 6);
    const user = [
      st.nome ? `CLIENTE: ${st.nome.split(' ')[0]}` : '',
      ctxItems.length ? 'CONTEXTO (peças):\n' + ctxItems.map((x) => Catalog.line(x) + ' ' + x.link.replace('https://', '')).join('\n') : 'CONTEXTO: nenhuma peça citada.',
      cls ? `Pista de intenção: ${cls.id} (${cls.score})` : '',
      'HISTÓRICO:\n' + st.hist.slice(-6, -1).map((h) => `${h.r}: ${h.t.slice(0, 160)}`).join('\n'),
      `MENSAGEM: ${raw.slice(0, 500)}`,
    ].filter(Boolean).join('\n');
    let out;
    try {
      out = await this.llm.complete(this.system, user);
    } catch (e) {
      console.error('[llm]', e.message);
      return { text: this.msg('erro', st), tier: 'erro', intent: 'erro_llm', handoff: 'erro de IA' };
    }
    st.llm++;
    st.cost = +(st.cost + out.cost).toFixed(6);
    const j = parseJSON(out.text);
    let text = String(j.r || '').trim() || this.msg('erro', st);
    // guarda de saída: se o LLM escapou das regras da marca (preço inventado, promessa, link de fora), não envia
    if (this.guard.some((r) => r.test(text))) {
      this.store.learn({ brand: this.id, norm, raw: raw.slice(0, 300), bloqueado: text.slice(0, 300), custo: out.cost });
      return { text: this.msg('erro', st), tier: 'llm', intent: 'bloqueado', handoff: 'resposta bloqueada', cost: out.cost, usage: out.usage, estimated: out.estimated };
    }
    const photos = (j.f || []).filter((id) => this.catalog?.get(id)).slice(0, 3);
    if (photos.length) st.products = photos;
    // só guarda em cache respostas que não dependem de peça específica
    if (!ctxItems.length && !j.h && text.length < 400) this.store.cacheSet(ck, { text, handoff: false });
    this.store.learn({ brand: this.id, norm, raw: raw.slice(0, 300), resposta: text, intent: j.i || null, pista: cls?.id || null, custo: out.cost });
    return { text, tier: 'llm', intent: j.i || 'llm', handoff: j.h ? 'llm' : false, photos, cost: out.cost, usage: out.usage, estimated: out.estimated };
  }

  // ---------- lembretes (só com consentimento, dentro de 24 h, no máximo 1 por conversa) ----------
  async runFollowups(now = Date.now()) {
    const rules = this.flowsR.followups;
    if (!rules.length) return 0;
    // horário de silêncio (padrão 21h–9h no fuso da marca)
    const q = this.flows.quiet_hours || this.b.quiet_hours || { inicio: 21, fim: 9, fuso: 'America/Sao_Paulo' };
    const h = +new Intl.DateTimeFormat('en-US', { hour: 'numeric', hourCycle: 'h23', timeZone: q.fuso || 'America/Sao_Paulo' }).format(new Date(now));
    if (q.inicio > q.fim ? h >= q.inicio || h < q.fim : h >= q.inicio && h < q.fim) return 0;
    let n = 0;
    for (const st of Object.values(this.store.conv)) {
      if (st.brand !== this.id || st.handoff || st.fuSent || !st.conv) continue;
      const f = st.flags || {};
      if (!(f.opt_in_followup || f.aceita_lembrete)) continue; // regra do dono: nada automático sem consentimento
      const silence = now - (st.ts || now);
      if (silence > 23.5 * 36e5) continue; // fora da janela grátis do WhatsApp
      for (const r of rules) {
        const stage = r.stage || String(r.when || '').match(/etapa\s+(\d-[\w-]+)/)?.[1];
        if (stage && st.stage !== stage) continue;
        if (r.audience && r.audience !== 'both' && st.audience && r.audience !== st.audience) continue;
        if (r.langs && st.lang && !r.langs.includes(st.lang)) continue;
        if (silence < (r.after_hours ?? r.within_hours ?? 20) * 36e5) continue;
        const text = this.fill(V(r, 'say', st) || '', st, st.slots || {});
        if (!text) break;
        try {
          const c = await this.cw.conversation(st.conv);
          if (c.status && c.status !== 'pending') { st.fuSent = 'equipe'; break; }
          await this.cw.send(st.conv, text, {});
          st.fuSent = r.id; this.hist(st, 'B', text); this.store.bump(this.id, 'lembretes'); this.store.touch(); n++;
        } catch (e) { console.error('[lembrete]', e.message); }
        break;
      }
    }
    return n;
  }

  // ---------- saída ----------
  hist(st, r, t) { st.hist.push({ r, t: String(t).slice(0, 300) }); if (st.hist.length > 12) st.hist.splice(0, st.hist.length - 12); }

  async reply(st, plan) {
    const conv = st.conv;
    if (st.slots?.cep && !st.cep) { const m = String(st.slots.cep).match(/(\d{5})-?(\d{3})/); if (m) st.cep = `${m[1]}-${m[2]}`; }
    const sent = [];
    if (plan.score) st.score += typeof plan.score === 'number' && plan.score > 1 ? plan.score : 0;
    // evita repetir exatamente a mesma resposta
    if (plan.intent === 'ofensa' && st.lastIntent === 'ofensa') plan.text = '';
    else if (plan.text && st.lastText === plan.text && plan.tier !== 'llm') plan.text = this.msg('repetido', st) || plan.text.split(/(?<=[.!?])\s+/)[0];
    st.lastIntent = plan.intent;
    if (plan.text) {
      const btns = (plan.buttons || []).filter(Boolean).slice(0, 3);
      st.btns = btns;
      // Instagram não recebe botões pelo Chatwoot: vira sugestão em texto (o cliente digita a opção)
      const interactive = this.cfg.botoes !== 'texto' && !/instagram/i.test(st.canal || '');
      const text = interactive || !btns.length ? plan.text : `${plan.text}\n\nResponda: ${btns.join(' · ')}`;
      await this.cw.send(conv, text, { buttons: btns, interactive });
      sent.push(text); st.lastText = plan.text; this.hist(st, 'B', plan.text);
    }
    for (const id of plan.photos || []) {
      const x = this.catalog?.get(id);
      if (!x) continue;
      try { await this.cw.sendImage(conv, x.img, `${x.nome} — ${fmtBRL(x.preco)}\n${x.link}`); sent.push('[foto] ' + x.nome); } catch (e) { console.error('[foto]', e.message); }
      st.lastOffer = null;
    }
    if (plan.photos?.length && !plan.text) this.hist(st, 'B', '[fotos] ' + plan.photos.join(','));
    // funil (só avança; etapas 5-7 são do humano)
    const stage = plan.handoff === 'fechamento' || plan.handoff === 'frete' ? '4-aguardando-pagamento' : plan.stage || (st.stage ? null : '1-novo-lead');
    const rank = (s) => this.stages.indexOf(s);
    const target = stage && (!st.stage || rank(stage) > rank(st.stage)) && rank(stage) <= 3 ? stage : null;
    const extra = plan.intent === 'lista_espera' ? ['lista-de-espera'] : [];
    for (const l of plan.labels || []) if (!this.stages.includes(l)) extra.push(l);
    if (st.audience && this.b.etiquetas?.publico?.[st.audience]) extra.push(this.b.etiquetas.publico[st.audience]);
    if (st.origem === 'anuncio' && !st.refLabel) { extra.push('origem-anuncio'); st.refLabel = true; }
    st.labelsSent ||= [];
    const newExtra = extra.filter((l) => !st.labelsSent.includes(l));
    if (target || newExtra.length || !st.brandLabel) {
      st.labelsSent.push(...newExtra);
      try { await this.cw.setStage(conv, target || st.stage, this.stages, [this.id, ...extra]); st.brandLabel = true; if (target) st.stage = target; } catch (e) { console.error('[etiqueta]', e.message); }
    }
    const notify = plan.notify || st.pendingNotify; st.pendingNotify = null;
    if (notify && !plan.handoff) { try { await this.cw.note(conv, notify); } catch (e) { console.error('[nota]', e.message); } }
    if (plan.handoff && !st.handoff) await this.handoff(st, plan.handoff);
    this.store.count(this.id, plan.tier, plan.cost || 0, plan.usage || null);
    st.tiers[plan.tier] = (st.tiers[plan.tier] || 0) + 1;
    if (plan.tier !== 'llm' && plan.tier !== 'cache') this.store.learn({ brand: this.id, tier: plan.tier, intent: plan.intent, norm: st.hist.at(-2)?.t?.slice(0, 200) });
    this.store.touch();
    return { ...plan, sent };
  }

  // nota interna para a equipe: lida em 10 segundos, com a ação a tomar (modelo em packs/<marca>/handoff_resumo.md)
  handoffNote(st, motivo) {
    const th = this.flows.lead_score_thresholds || {};
    const sc = Math.round(st.score || 0);
    const temp = Array.isArray(th) ? (th.find((r) => sc >= (r.min ?? -1e9) && sc <= (r.max ?? 1e9))?.faixa || '') : sc >= (th.muito_quente ?? 80) ? 'muito quente' : sc >= (th.quente ?? 50) ? 'quente' : sc >= (th.morno ?? 20) ? 'morno' : 'frio';
    const acoes = this.aj.acoes_transbordo || this.b.acoes_transbordo || {};
    const key = Object.keys(acoes).find((k) => new RegExp(k, 'i').test(motivo));
    const sl = st.slots || {};
    const x = st.focus && this.catalog?.get(st.focus);
    const outras = (st.products || []).filter((id) => id !== st.focus).map((id) => this.catalog?.get(id)).filter(Boolean).slice(0, 2);
    const objMap = this.aj.objecoes || {};
    const obj = [...new Set(Object.keys(st.used || {}).map((id) => objMap[id]).filter(Boolean))];
    const lastC = [...(st.hist || [])].reverse().find((h) => h.r === 'C');
    const canal = (st.canal || '').replace(/^Channel::/, '').replace('Whatsapp', 'WhatsApp').replace('FacebookPage', 'Messenger').replace('WebWidget', 'site');
    const vars = { cep: st.cep || sl.cep ? `para o CEP ${st.cep || sl.cep}` : '(pedir o CEP)', pagamento: sl.pagamento || 'Pix ou cartão', pedido: st.pedido || '' };
    const acao = key ? acoes[key].replace(/\{\{(\w+)\}\}/g, (_, k) => vars[k] ?? '') : 'Ler a conversa e assumir.';
    const L = [
      `TRANSBORDO · ${motivo} · ${temp} (${sc} pts)`,
      `Fazer agora: ${acao}`,
      [st.nome ? `Cliente: ${st.nome}` : 'Cliente', canal, st.origem === 'anuncio' ? `anúncio: ${st.ref?.titulo || 'sim'}` : '', st.lang && st.lang !== this.lang0 ? `idioma: ${st.lang}` : ''].filter(Boolean).join(' · '),
      x ? `Peça: ${x.nome} · ${this.priceTxt(x)}${(x.tamanhos || []).length ? ' · tam. ' + x.tamanhos.join(', ') : ''}${st.waitSize ? ' · pediu ' + st.waitSize : ''} · ${x.link.replace('https://', '')}` : (st.products || []).length ? '' : (this.catalog ? 'Peça: não identificada (perguntar qual)' : ''),
      outras.length ? `${x ? 'Também viu' : 'Viu'}: ${outras.map((y) => `${y.nome} · ${fmtBRL(y.preco)}`).join(' | ')}` : '',
      st.pedido ? `Pedido do site: ${st.pedido}` : '',
      sl.entrega || st.cep ? `Entrega: ${[sl.entrega, st.cep || sl.cep ? 'CEP ' + (st.cep || sl.cep) : '', sl.cidade].filter(Boolean).join(' · ')}` : '',
      sl.pagamento ? `Pagamento: ${sl.pagamento}` : '',
      sl.para_quem || sl.faixa ? `Perfil: ${[sl.para_quem ? 'presente ' + sl.para_quem : '', sl.faixa ? 'faixa ' + sl.faixa : ''].filter(Boolean).join(' · ')}` : '',
      Object.keys(sl).filter((k) => !['cep', 'entrega', 'pagamento', 'para_quem', 'faixa', 'cidade', 'lgpd_consent', 'lgpd_consent_em', 'genero'].includes(k)).length ? `Respostas: ${Object.entries(sl).filter(([k]) => !['cep', 'entrega', 'pagamento', 'para_quem', 'faixa', 'cidade', 'lgpd_consent', 'lgpd_consent_em', 'genero'].includes(k)).map(([k, v]) => `${k}: ${String(v).slice(0, 40)}`).join(' · ')}` : '',
      obj.length ? `Dúvidas e objeções: ${obj.join(', ')}` : '',
      st.flags?.opt_in_followup || st.flags?.lista_espera ? `Lembrete aceito: ${st.flags.opt_in_followup ? 'sim' : 'não'}${st.flags.lista_espera ? ' · lista de espera: ' + st.flags.lista_espera : ''}` : '',
      lastC ? `Cliente disse: "${lastC.t.slice(0, 140)}"` : '',
      `IA: US$ ${st.cost.toFixed(4)} (${st.llm} chamadas) · ${st.msgs} mensagens`,
    ];
    return L.filter(Boolean).join('\n');
  }

  async handoff(st, motivo) {
    st.handoff = true;
    this.store.bump(this.id, 'transbordos');
    const nota = this.handoffNote(st, motivo);
    try { await this.cw.note(st.conv, nota); await this.cw.status(st.conv, 'open'); } catch (e) { console.error('[transbordo]', e.message); }
  }

}

export const DEFAULT_MSG = {
  saudacao_curta: '{{saudacao}}!',
  audio: 'Por aqui não consigo ouvir áudio. Pode me escrever? Respondo na hora.',
  imagem: 'Recebi a imagem. Me diz o nome ou o tipo da peça que eu procuro para você.',
  cep_recebido: 'Obrigado! Com o CEP {{cep}} a equipe calcula o frete e o prazo e já te responde por aqui.',
  comprar: 'Ótima escolha! Você pode finalizar pelo site: {{link}}. Se preferir, a equipe fecha com você por aqui (frete pelo CEP, Pix ou cartão).',
  transbordo: 'Vou chamar a equipe para continuar com você por aqui. Em instantes alguém responde.',
  fotos_seguem: 'Seguem as fotos:',
  quer_fotos: 'Quer ver as fotos?',
  pos_preco: 'Quer que eu mande as fotos ou o link de compra?',
  tamanho_unico: '{{produto}} é tamanho único.',
  tamanho_tem: 'Temos no {{tam}}, sim. Quer o link para garantir?',
  tamanho_nao_tem: 'No {{tam}} não temos. Disponíveis: {{tams}}.',
  tamanhos_disp: '{{produto}}: tamanhos disponíveis {{tams}}.',
  link_produto: 'Aqui está: {{link}}',
  sem_resultado: 'No momento não temos {{item}}. Posso te avisar quando chegar algo parecido?',
  sem_resultado_alt: 'Não temos {{item}} agora, mas veja estas opções:',
  lista_intro: 'Separei estas para você:',
  lista_pergunta: 'Qual te interessou? Posso mandar as fotos.',
  ver_todas: 'Tenho {{total}} no total. Para ver todas com foto: {{link}}',
  ver_site: 'Você vê todas as peças em {{site}}. Quer que eu filtre por tipo, cor ou faixa de preço?',
  fim_lista: 'Essas eram todas. Você também vê tudo em {{link}}',
  repetido: '',
  limite: 'Vou pedir para a equipe te responder isso com cuidado. Em instantes alguém continua por aqui.',
  erro: 'Vou pedir para a equipe confirmar isso para você. Em instantes alguém responde.',
  cinto_cm: 'Para cintura de {{cm}} cm, os tamanhos mais próximos acima são:',
  sem_cor: 'Não temos {{item}} agora. Nessa linha temos: {{cores}}. Qual quer ver?',
  diferenca_fim: 'Quer que eu mande as fotos lado a lado?',
  mesmo_preco: 'Têm o mesmo preço ({{preco}}); muda o modelo:',
  pagamento_obs: 'Pagamento por Pix ou cartão, por link seguro; as condições a equipe confirma no fechamento.',
  tamanho_confirma: 'A equipe confirma o caimento antes de fechar.',
  lista_espera_ok: 'Anotado: {{produto}}. Se chegar, a equipe te avisa por aqui.',
  sem_outra_cor: 'Esse modelo nós temos só nessa cor. Quer ver opções parecidas?',
  tamanho_lista: 'No {{tam}} temos:',
  tamanho_nenhum: 'No {{tam}} não temos nessas opções. Tamanhos disponíveis:',
  foto_equipe: 'Vou pedir para a equipe olhar a sua foto e confirmar se temos essa peça. Em instantes alguém responde por aqui.',
  pedido_site: 'Recebemos seu pedido {{pedido}}! A equipe confere o estoque, o frete e o pagamento e te responde por aqui em instantes.',
  interesse_site: 'Ótima escolha! Essa peça está disponível:',
};

// textos padrão em outros idiomas (marcas multilíngues sobrescrevem em brand.json: mensagens_<idioma>)
export const DEFAULT_MSG_LANG = {
  en: {
    saudacao_curta: 'Hi!', audio: "I can't listen to voice notes here. Could you type it? I reply right away.",
    imagem: 'Got your image. Tell me what you are looking for and I will help.',
    transbordo: "I'm passing this to our team. A person will reply here soon.",
    limite: 'Let me ask our team to answer this one properly. A person will reply here soon.',
    erro: 'Let me check this with our team. A person will reply here soon.', repetido: '',
  },
  es: {
    saudacao_curta: '¡Hola!', audio: 'Aquí no puedo escuchar audios. ¿Me lo escribes? Respondo enseguida.',
    imagem: 'Recibí tu imagen. Cuéntame qué buscas y te ayudo.',
    transbordo: 'Paso tu mensaje al equipo. Una persona te responde aquí en breve.',
    limite: 'Voy a pedir al equipo que responda esto con cuidado. Una persona te responde aquí en breve.',
    erro: 'Voy a confirmarlo con el equipo. Una persona te responde aquí en breve.', repetido: '',
  },
};
