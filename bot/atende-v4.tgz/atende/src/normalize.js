// Normalização de texto de WhatsApp em português (e EN/ES): sem acento, minúsculo,
// letras repetidas colapsadas ("oiiii" -> "oi"), sinônimos/abreviações por palavra.

const BASE_SYN = {
  vc: 'voce', vcs: 'voces', voce: 'voce', ce: 'voce', cê: 'voce',
  q: 'que', oq: 'o que', pq: 'porque', porq: 'porque', tb: 'tambem', tbm: 'tambem',
  qto: 'quanto', qnto: 'quanto', qt: 'quanto', qnt: 'quanto', qual: 'qual', ql: 'qual',
  msg: 'mensagem', obg: 'obrigado', obgd: 'obrigado', obrigada: 'obrigado', vlw: 'valeu', blz: 'beleza',
  td: 'tudo', tds: 'todos', hj: 'hoje', amanha: 'amanha', mto: 'muito', mt: 'muito', mtu: 'muito',
  pfv: 'por favor', pf: 'por favor', pfvr: 'por favor', plz: 'por favor', ok: 'ok', okay: 'ok',
  tbem: 'tambem', cmg: 'comigo', ctg: 'contigo', dps: 'depois', agr: 'agora', nd: 'nada',
  nn: 'nao', naum: 'nao', sim: 'sim', s: 'sim', ss: 'sim', aham: 'sim', uhum: 'sim',
  tem: 'tem', tm: 'tem', tens: 'tem', teria: 'tem', teriam: 'tem', possui: 'tem',
  rs: '', rsrs: '', kk: '', kkk: '', haha: '', hahaha: '', kkkk: '',
  zap: 'whatsapp', wpp: 'whatsapp', whats: 'whatsapp', insta: 'instagram',
  r: 'reais', rs$: 'reais', brl: 'reais', mil: 'mil', k: 'mil',
};

export function stripAccents(s) {
  return s.normalize('NFD').replace(/[̀-ͯ]/g, '');
}

export function makeNormalizer(extraSyn = {}) {
  const syn = { ...BASE_SYN };
  for (const [k, v] of Object.entries(extraSyn || {})) {
    const kk = stripAccents(String(k).toLowerCase()).trim();
    if (kk) syn[kk] = stripAccents(String(v).toLowerCase()).trim();
  }
  return function normalize(text) {
    let s = stripAccents(String(text || '').toLowerCase());
    s = s.replace(/r\$\s*/g, ' reais ');
    s = s.replace(/(\d)\.(\d{3})\b/g, '$1$2'); // 15.840 -> 15840
    s = s.replace(/(\d),(\d{1,2})\b/g, '$1.$2'); // 9,5 -> 9.5
    s = s.replace(/[^a-z0-9.\s]/g, ' ').replace(/\s\.|\.\s|^\.|\.$/g, ' ');
    s = s.replace(/([a-z])\1{2,}/g, '$1');
    const out = [];
    for (const w of s.split(/\s+/)) {
      if (!w) continue;
      const m = syn[w];
      if (m === undefined) out.push(w);
      else if (m) out.push(m);
    }
    return out.join(' ').trim();
  };
}

export const normalize = makeNormalizer();

// Números por extenso comuns (para "a segunda", "o terceiro")
export const ORDINAIS = { primeira: 1, primeiro: 1, '1a': 1, segunda: 2, segundo: 2, '2a': 2, terceira: 3, terceiro: 3, '3a': 3, quarta: 4, quarto: 4, quinta: 5, quinto: 5, ultima: -1, ultimo: -1 };
