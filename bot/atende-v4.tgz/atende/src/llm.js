// Camada de LLM: só é chamada quando regras, catálogo e cache não resolvem.
// Contexto mínimo, saída curta em JSON, prompt caching na Anthropic, medidor de custo.

// US$ por 1 milhão de tokens: [entrada, saída, gravação de cache 5 min, leitura de cache] (out/2026)
export const PRICES = {
  'claude-haiku-5-5': [0.1, 0.5, 0.125, 0.01],
  'claude-haiku-4-5': [1, 5, 1.25, 0.1],
  'claude-sonnet-5-5': [2, 10, 2.5, 0.1],
  'gpt-6-luna': [0.1, 0.5, 0, 0.01],
  'gpt-5.4-nano': [0.1, 0.625, 0, 0.01],
  'gemini-3.1-flash-lite': [0.25, 1.5, 0, 0.025],
  'gemini-3.5-flash-lite': [0.3, 2.5, 0, 0.03],
  'deepseek-flash': [0.3, 1.2, 0, 0.006],
  'qwen3.7-flash': [0.03, 0.13, 0, 0.003],
  local: [0, 0, 0, 0],
};
export const DEFAULT_MODEL = 'claude-haiku-5-5';

// mínimo de tokens para a Anthropic aceitar cache (abaixo disso o cache_control é ignorado em silêncio)
const MIN_CACHE = { 'claude-haiku-5-5': 512, 'claude-sonnet-5-5': 512, 'claude-opus-5': 512, 'claude-sonnet-5': 1024, 'claude-haiku-4-5': 4096 };
// modelos da geração 5+: sem temperature, sem prefill, thinking desligável e "effort"
const NEW_GEN = /^claude-(haiku|sonnet|opus)-5|^claude-(opus|sonnet)-4-[6-9]/;

const pick = (table, model, def) => { const k = Object.keys(table).sort((a, b) => b.length - a.length).find((p) => model && model.startsWith(p)); return k ? table[k] : def; };
export const priceOf = (model) => pick(PRICES, model, PRICES[DEFAULT_MODEL]);

export function costUSD(model, u) {
  const [pi, po, pw, pr] = priceOf(model);
  return ((u.input || 0) * pi + (u.output || 0) * po + (u.cache_write || 0) * pw + (u.cache_read || 0) * pr) / 1e6;
}

// estimativa offline em português: ~3,6 caracteres por token no tokenizer antigo; o novo (Claude 4.7+/5.x) gera ~30% mais
export const estTokens = (s, model = DEFAULT_MODEL) => Math.ceil(String(s || '').length / (NEW_GEN.test(model) ? 2.8 : 3.6));

export class LLM {
  constructor(cfg) {
    this.provider = cfg.provider || 'anthropic';
    this.model = cfg.model || DEFAULT_MODEL;
    this.key = cfg.apiKey;
    this.baseUrl = cfg.baseUrl;
    this.maxTokens = cfg.maxTokens || 220;
    this.timeoutMs = cfg.timeoutMs || 12000;
    this.mock = cfg.mock || null; // função (system, user) => texto JSON, para simulação
    this.minCache = pick(MIN_CACHE, this.model, 1024);
  }

  async complete(system, user) {
    if (this.mock) {
      const text = await this.mock(system, user);
      const e = (s) => estTokens(s, this.model);
      const u = { input: e(system) + e(user), output: e(text), cache_write: 0, cache_read: 0 };
      if (this.cacheable(system)) { u.cache_read = e(system); u.input = e(user); }
      return { text, usage: u, cost: costUSD(this.model, u), estimated: true };
    }
    if (this.provider === 'anthropic') return this.anthropic(system, user);
    return this.openai(system, user);
  }

  cacheable(system) { return this.provider === 'anthropic' && estTokens(system, this.model) >= this.minCache; }

  async post(url, headers, body) {
    const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body), signal: AbortSignal.timeout(this.timeoutMs) });
    const j = await r.json().catch(() => ({}));
    return { ok: r.ok, status: r.status, j };
  }

  async anthropic(system, user) {
    const newGen = NEW_GEN.test(this.model);
    const sys = [{ type: 'text', text: system, ...(this.cacheable(system) ? { cache_control: { type: 'ephemeral' } } : {}) }];
    const body = newGen
      ? { model: this.model, max_tokens: this.maxTokens, thinking: { type: 'disabled' }, output_config: { effort: 'low' }, system: sys, messages: [{ role: 'user', content: user }] }
      : { model: this.model, max_tokens: this.maxTokens, temperature: 0.3, system: sys, messages: [{ role: 'user', content: user }, { role: 'assistant', content: '{' }] };
    const headers = { 'x-api-key': this.key, 'anthropic-version': '2023-06-01' };
    let res = await this.post('https://api.anthropic.com/v1/messages', headers, body);
    if (!res.ok && res.status === 400 && newGen) {
      // parâmetro recusado: tenta uma vez com o corpo mínimo
      console.error('[llm] 400, repetindo sem thinking/effort:', JSON.stringify(res.j).slice(0, 200));
      res = await this.post('https://api.anthropic.com/v1/messages', headers, { model: this.model, max_tokens: this.maxTokens + 300, system: sys, messages: [{ role: 'user', content: user }] });
    }
    if (!res.ok) throw new Error('anthropic ' + res.status + ' ' + JSON.stringify(res.j).slice(0, 300));
    const j = res.j;
    if (j.stop_reason === 'refusal') throw new Error('anthropic recusou');
    const txt = (j.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('');
    const text = newGen ? txt : '{' + txt;
    const u = { input: j.usage?.input_tokens || 0, output: j.usage?.output_tokens || 0, cache_write: j.usage?.cache_creation_input_tokens || 0, cache_read: j.usage?.cache_read_input_tokens || 0 };
    return { text, usage: u, cost: costUSD(this.model, u) };
  }

  // Qualquer API compatível com OpenAI: OpenAI, Gemini (endpoint compatível), DeepSeek, Qwen, Ollama local
  async openai(system, user) {
    const reasoning = /^(gpt-5|gpt-6|o\d)/.test(this.model);
    const body = { model: this.model, response_format: { type: 'json_object' }, messages: [{ role: 'system', content: system }, { role: 'user', content: user }] };
    if (reasoning) { body.max_completion_tokens = this.maxTokens + 200; body.reasoning_effort = 'low'; } else { body.max_tokens = this.maxTokens; body.temperature = 0.3; }
    const res = await this.post((this.baseUrl || 'https://api.openai.com/v1') + '/chat/completions', { authorization: 'Bearer ' + (this.key || 'x') }, body);
    if (!res.ok) throw new Error('llm ' + res.status + ' ' + JSON.stringify(res.j).slice(0, 300));
    const j = res.j;
    const text = j.choices?.[0]?.message?.content || '{}';
    const cached = j.usage?.prompt_tokens_details?.cached_tokens || j.usage?.prompt_cache_hit_tokens || 0;
    const u = { input: (j.usage?.prompt_tokens || 0) - cached, output: j.usage?.completion_tokens || 0, cache_read: cached, cache_write: 0 };
    return { text, usage: u, cost: costUSD(this.model, u) };
  }
}

export function parseJSON(text) {
  const s = String(text || '').replace(/^```(?:json)?\s*|\s*```$/g, '');
  try { return JSON.parse(s); } catch {}
  const m = s.match(/\{[\s\S]*\}/);
  if (m) { try { return JSON.parse(m[0]); } catch {} }
  return { r: s.replace(/^\{?\s*"?r"?\s*:\s*"?/, '').replace(/"?\s*,?\s*"?h"?\s*:.*$/s, '').replace(/"?\s*\}?$/, '').slice(0, 600) };
}
