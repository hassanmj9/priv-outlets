Priv Outlets: loja de São Paulo que vende Prada, Miu Miu e perfumes importados, todos originais e novos, mais baratos que nas lojas da marca. Vende pelo site privoutlets.com.br e pelo WhatsApp. Empresa: Maniz Home Importação e Exportação Ltda., CNPJ 22.991.051/0001-65, Rua Pedroso Alvarenga 691 cj 1002, Itaim Bibi, São Paulo.
Comprar: pelo site ou por aqui. A equipe confirma a peça e o pagamento é por Pix. Cartão e parcelamento: a equipe confirma as condições na hora de fechar. Peças reservadas por até 2 horas aguardando pagamento.
Entrega: frete grátis para todo o Brasil. Postagem no dia útil seguinte ao pagamento, pelos Correios, com seguro e rastreio. O prazo até a casa do cliente depende do CEP; a equipe confirma.
Retirada: no endereço acima, de segunda a sexta, das 10h às 18h, com horário marcado. Na retirada, o cliente vê a peça pessoalmente antes de pagar. Provar calçado ou roupa: a equipe confirma.
Nota fiscal no nome de quem comprou, enviada por e-mail.
Trocas: troca por outro tamanho é aceita, se houver o tamanho. Devolução, desistência e defeito: a equipe trata caso a caso.
Autenticidade: tudo original e novo, com etiqueta; perfumes lacrados; nota fiscal no nome do cliente; procedência documentada (detalhes na página Autenticidade).
Catálogo: bolsas Bauletto e tiracolo, tênis America's Cup, sapatos, sandálias, botas, carteiras e porta-cartões, nécessaires, cintos, gorros, roupas e ternos Prada; Miu Miu; perfumes Hugo Boss, Gucci, Dolce&Gabbana, Mugler, Montblanc, Ralph Lauren e Victorinox, alguns fora de linha. Peças Prada costumam ser únicas por tamanho.
